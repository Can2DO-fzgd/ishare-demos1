/** Automatically generated file. DO NOT MODIFY */
package com.can2do.ishare;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}