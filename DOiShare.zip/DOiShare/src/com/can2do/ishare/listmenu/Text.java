package com.can2do.ishare.listmenu;

import com.can2do.ishare.R;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.widget.ArrayAdapter;

@SuppressLint("NewApi")
public class Text extends Activity implements ActionBar.OnNavigationListener {

	ActionBar actionBar = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_listmenu_text);

		actionBar = this.getActionBar();

		actionBar.setDisplayShowTitleEnabled(true);

		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);

		actionBar.setListNavigationCallbacks(new ArrayAdapter(Text.this,R.layout.ui_listmenu_mytextview, R.id.text1, new String[] { "�˵�һ", "�˵���", "�˵���" }), this);

	}

	@Override
	public boolean onNavigationItemSelected(int itemPosition, long itemId) {

		TextFragment mf = new TextFragment();
		Bundle bundle = new Bundle();
		bundle.putInt("key", itemPosition + 1);
		mf.setArguments(bundle);

		FragmentTransaction action = this.getFragmentManager()
				.beginTransaction();
		action.replace(R.id.content, mf);
		action.commit();
		return true;
	}

}