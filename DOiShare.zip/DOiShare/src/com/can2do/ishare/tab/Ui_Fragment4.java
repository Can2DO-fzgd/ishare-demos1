package com.can2do.ishare.tab;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.can2do.ishare.R;
import com.can2do.ishare.base.GuestC;
import com.can2do.ishare.jquery.Indexhtml1;
import com.can2do.ishare.jquery.Indexhtml2;
import com.can2do.ishare.jquery.Indexhtml4;

public class Ui_Fragment4 extends Fragment {

	@Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		
        this.getView().findViewById(R.id.content_btn1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml4.class);
                in.putExtra("url", GuestC.web.content1);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.content1, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.content_btn2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml4.class);
                in.putExtra("url", GuestC.web.content2);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.content2, Toast.LENGTH_SHORT).show();
            }
        });
        
//        this.getView().findViewById(R.id.content_btn3).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content3);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content3, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn4).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content4);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content4, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn5).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content5);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content5, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn6).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content6);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content6, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn7).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content7);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content7, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn8).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content8);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content8, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn9).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content9);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content9, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn10).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content10);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content10, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn11).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content11);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content11, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.content_btn12).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                 
//                Intent in=new Intent(getActivity(),Indexhtml4.class);
//                in.putExtra("url", GuestC.web.content12);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.content12, Toast.LENGTH_SHORT).show();
//            }
//        });
        
        
    }
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflateAndSetupView(inflater, container, savedInstanceState, R.layout.ui_tab_fragment4);
	}
	
	private View inflateAndSetupView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState, int layoutResourceId) {
		View layout = inflater.inflate(layoutResourceId, container, false);
		
		return layout;
	} 
}
