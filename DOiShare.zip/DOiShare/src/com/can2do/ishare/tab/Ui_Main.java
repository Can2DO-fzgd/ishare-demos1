package com.can2do.ishare.tab;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;

import com.can2do.ishare.R;

public class Ui_Main extends FragmentActivity 
				implements ActionBar.TabListener{
    
	Ui_Fragment1 mFragment1 = new Ui_Fragment1();
	Ui_Fragment2 mFragment2 = new Ui_Fragment2();
	Ui_Fragment3 mFragment3 = new Ui_Fragment3();
	Ui_Fragment4 mFragment4 = new Ui_Fragment4();
	
	private static final int TAB_INDEX_COUNT = 4;
	
	private static final int TAB_INDEX_ONE = 0;
	private static final int TAB_INDEX_TWO = 1;
	private static final int TAB_INDEX_THREE = 2;
	private static final int TAB_INDEX_FIVE = 3;
	
	private ViewPager mViewPager;
	private ViewPagerAdapter mViewPagerAdapter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_tab_main);
        
        setUpActionBar();
        setUpViewPager();
        setUpTabs();
    }
    
    private void setUpActionBar() {
    	final ActionBar actionBar = getActionBar();
    	actionBar.setHomeButtonEnabled(false);
    	actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);// NAVIGATION_MODE_TABS������ʾTab����ģʽ
    	actionBar.setDisplayShowTitleEnabled(false);
    	actionBar.setDisplayShowHomeEnabled(false);
    }
    
    private void setUpViewPager() {
    	mViewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
    	
    	mViewPager = (ViewPager)findViewById(R.id.pager);
    	mViewPager.setAdapter(mViewPagerAdapter);
    	mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
    		@Override
    		public void onPageSelected(int position) {
    			final ActionBar actionBar = getActionBar();
    			actionBar.setSelectedNavigationItem(position);
    		}
    		
    		@Override
    		public void onPageScrollStateChanged(int state) {
    			switch(state) {
    				case ViewPager.SCROLL_STATE_IDLE:
    					break;
    				case ViewPager.SCROLL_STATE_DRAGGING:
    					break;
    				case ViewPager.SCROLL_STATE_SETTLING:
    					break;
    				default:
    					break;
    			}
    		}
    	});
    }
    
    private void setUpTabs() {
    	final ActionBar actionBar = getActionBar();
    	for (int i = 0; i < mViewPagerAdapter.getCount(); ++i) {
    		actionBar.addTab(actionBar.newTab()
    				.setText(mViewPagerAdapter.getPageTitle(i))
    				.setTabListener(this));
    	}
    }
    
    @Override
    protected void onDestroy() {
    	super.onDestroy();
    }
    
    public class ViewPagerAdapter extends FragmentPagerAdapter {

		public ViewPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			switch (position) {
				case TAB_INDEX_ONE:
					return mFragment1;
				case TAB_INDEX_TWO:
					return mFragment2;
				case TAB_INDEX_THREE:
					return mFragment3;
				case TAB_INDEX_FIVE:
					return mFragment4;
			}
			throw new IllegalStateException("No fragment at position " + position);
		}

		@Override
		public int getCount() {
			return TAB_INDEX_COUNT;
		}
    	
		@Override
		public CharSequence getPageTitle(int position) {
			String tabLabel = null;
			switch (position) {
				case TAB_INDEX_ONE:
					tabLabel = getString(R.string.tab_1);
					break;
				case TAB_INDEX_TWO:
					tabLabel = getString(R.string.tab_2);
					break;
				case TAB_INDEX_THREE:
					tabLabel = getString(R.string.tab_3);
					break;
				case TAB_INDEX_FIVE:
					tabLabel = getString(R.string.tab_4);
					break;
			}
			return tabLabel;
		}
    }

    // Tab��ѡ�к��û��ٴ�ѡ�и�Tab��ִ�еĴ��룬ͨ�������κ�����
	@Override
	public void onTabReselected(Tab tab, FragmentTransaction ft) {
	}

	// Tabѡ��ʱҪִ�еĴ���
	@Override
	public void onTabSelected(Tab tab, FragmentTransaction ft) {
		mViewPager.setCurrentItem(tab.getPosition());
	}

	// Tab�뿪ѡ��״̬ʱִ�еĴ���
	@Override
	public void onTabUnselected(Tab tab, FragmentTransaction ft) {
	}
	
}