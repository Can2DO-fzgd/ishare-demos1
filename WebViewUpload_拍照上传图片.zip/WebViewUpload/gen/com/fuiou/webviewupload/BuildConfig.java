/** Automatically generated file. DO NOT MODIFY */
package com.fuiou.webviewupload;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}