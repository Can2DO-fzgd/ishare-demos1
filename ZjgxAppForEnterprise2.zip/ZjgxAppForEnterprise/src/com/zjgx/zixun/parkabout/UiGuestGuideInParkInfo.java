package com.zjgx.zixun.parkabout;

import com.zjgx.zixun.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class UiGuestGuideInParkInfo extends Activity {
	private TextView info;
	private Button goBack;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_guide_in_park_info);
		String detail=getIntent().getStringExtra("info");
		info=(TextView)findViewById(R.id.info);
		goBack=(Button)findViewById(R.id.goBack);
		info.setText(detail);
		goBack.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(UiGuestGuideInParkInfo.this,UiGuestGuideInPark.class);
				startActivity(intent);
				finish();				
			}
		});
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(UiGuestGuideInParkInfo.this,UiGuestGuideInPark.class);
			startActivity(intent);
			this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
