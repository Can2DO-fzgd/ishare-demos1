﻿package com.zjgx.zixun.parkabout;

import com.zjgx.zixun.R;
import com.zjgx.zixun.ui.UiContentUs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class UiGuideInPark extends Activity {
	private String[] info = new String[] {
			"\t\t紫金（高新）科技创业特别社区企业入孵条件\n\t\t【规范目的】：为规范公司招商工作，确保企业入园工作有条不紊开展，特制订本办法。。\n\t\t【企业入孵条件】\n\t\t1、入孵企业需符合南京高新技术产业开发区产业范围：软件及系统集成、生物医药、新能源新材料等特色产业集群；\n\t\t2、企业注册地和主要研发、办公场所须在本孵化器场地内；\n\t\t3、申请入孵企业，成立时间一般不超过24个月；\n\t\t4、属迁入的企业，其产品（或服务）尚处于研发或试销阶段，上年营业收入不超过1000万元人民币；\n\t\t5、在孵时限一般不超过42个月（纳入“创新人才推进计划”及“海外高层次人才引进计划”的人才或从事生物医药、集成电路设计、现代农业等特殊领域的创业企业，一般不超过60个月）；\n\t\t6、企业成立时的注册资金，扣除“知识产权出资”后，现金部分一般不超过500万元人民币（属生物医药、集成电路设计等特殊领域的创业企业，一般不超过1000万元人民币）；\n\t\t7、单一在孵企业入驻时使用的孵化场地面积，一般不大于500平方米（从事航空航天等特殊领域的在孵企业，一般不大于1000平方米）；\n\t\t8、在孵企业从事研发、生产的主营项目（产品），应符合国家战略性新兴产业的发展导向，并符合国家节能减排标准；\n\t\t9、在孵企业开发的项目（产品），知识产权界定清晰，无纠纷；\n\t\t10、在孵企业团队具有开拓创新精神，对技术、市场、经营和管理有一定驾驭能力。留学生和大学生企业的团队主要管理者或技术带头人，由其本人担任。"
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 ",
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 ",
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 ",
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 ",
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 ",
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 ",
//			"\t\t指南二•联系我们 \n\t\t【联系我们】：。\n\t\t【在线留言】：。 "
			};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_guide_in_park);
		//SysApplication.getInstance().addActivity(this);
		int[] btnIds = new int[] { R.id.zhina1
//				R.id.zhina2, R.id.zhina3,
//				R.id.zhina4, R.id.zhina5, R.id.zhina6, R.id.zhina7,
//				R.id.zhina8 
				};
		Button[] btns = new Button[btnIds.length];
		myOnClickListener myListener = new myOnClickListener();
		for (int i = 0; i < btns.length; i++) {
			btns[i] = (Button) findViewById(btnIds[i]);
			btns[i].setOnClickListener(myListener);
		}
	}

	private class myOnClickListener implements OnClickListener {
		Intent intent = new Intent(UiGuideInPark.this,
				UiGuideInParkInfo.class);
		@Override
		public void onClick(View v) {
			switch (v.getId()) {

			case R.id.zhina1:
				intent.putExtra("info", info[0]);
				break;
//			case R.id.zhina2:
//				intent.putExtra("info", info[1]);
//				break;
//			case R.id.zhina3:
//				intent.putExtra("info", info[2]);
//				break;
//			case R.id.zhina4:
//				intent.putExtra("info", info[3]);
//				break;
//			case R.id.zhina5:
//				intent.putExtra("info", info[4]);
//				break;
//			case R.id.zhina6:
//				intent.putExtra("info", info[5]);
//				break;
//			case R.id.zhina7:
//				intent.putExtra("info", info[6]);
//				break;
//			case R.id.zhina8:
//				intent.putExtra("info", info[7]);
//				break;
			default:
				break;
			}
			startActivity(intent);
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(UiGuideInPark.this,UiContentUs.class);
			startActivity(intent);
			this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
