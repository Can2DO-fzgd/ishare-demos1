package com.zjgx.zixun.util;

import com.zjgx.zixun.R;
import com.zjgx.zixun.model.Customer;
import com.zjgx.zixun.model.Customer1;

import android.content.Context;
import android.content.res.Resources;

public class UIUtil {

	// tag for log
	//	private static String TAG = UIUtil.class.getSimpleName();
	
	public static String getCustomerInfo (Context ctx, Customer customer) {
		Resources resources = ctx.getResources();
		StringBuffer sb = new StringBuffer();
		sb.append(resources.getString(R.string.customer_news));
		sb.append(" ");
		sb.append(customer.getNewscount());
		sb.append(" | ");
		sb.append(resources.getString(R.string.customer_fans));
		sb.append(" ");
		sb.append(customer.getFanscount());
		return sb.toString();
	}
	
	public static String getCustomer1Info (Context ctx, Customer1 customer) {
		Resources resources = ctx.getResources();
		StringBuffer sb = new StringBuffer();
		sb.append(resources.getString(R.string.customer_news));
		sb.append(" ");
		sb.append(customer.getNewscount());
		sb.append(" | ");
		sb.append(resources.getString(R.string.customer_fans));
		sb.append(" ");
		sb.append(customer.getFanscount());
		return sb.toString();
	}
}