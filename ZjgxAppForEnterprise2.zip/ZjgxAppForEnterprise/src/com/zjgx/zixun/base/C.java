package com.zjgx.zixun.base;

import android.annotation.SuppressLint;

public final class C {
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// core settings (important)
	
	public static final class dir {
		@SuppressLint("SdCardPath")
		public static final String base				= "/sdcard/ZJGX";
		public static final String faces			= base + "/faces";
		public static final String images			= base + "/images";
	}
	
	public static final class api {
		public static final String base					= "http://www.can2do.com:8001";
		//public static final String base				    = "http://api.njibi.com.cn";
		public static final String index			    = "/index/index";
		public static final String login			    = "/index/login";
		public static final String register			    = "/index/register";
		public static final String logout		     	= "/index/logout";
		public static final String faceView 			= "/image/faceView";
		public static final String faceList 			= "/image/faceList";
		public static final String zixunList			= "/zjgxzixun/zixunList";
		public static final String zixunView			= "/zjgxzixun/zixunView";
		public static final String zixunCreate			= "/zjgxzixun/zixunCreate";
		public static final String zixunCollectList		= "/zjgxzixuncollect/collectList";
		public static final String zixunCollect			= "/zjgxzixuncollect/collectCreate";
		public static final String zixunTypesList		= "/zjgxzixun/zixunTypesList";
		public static final String zixunTypes			= "/zjgxzixun/zixunTypes";
		public static final String commentList			= "/zjgxzixuncomment/commentList";
		public static final String commentCreate		= "/zjgxzixuncomment/commentCreate";
		public static final String customerView			= "/customer/customerView";
		public static final String customerEdit			= "/customer/customerEdit";
		public static final String fansAdd				= "/customer/fansAdd";
		public static final String newsnoticeAdd		= "/notify/newsnoticeAdd";
		public static final String fansDel				= "/customer/fansDel";
		public static final String notice				= "/notify/notice";
		public static final String demandList			= "/zjgxdemand/demandList";
		public static final String demandTypesList		= "/zjgxdemand/demandTypesList";
		public static final String demandView			= "/zjgxdemand/demandView";
		public static final String enterpriseList		= "/zjgxcost/enterpriseList";
		public static final String costTypesList		= "/zjgxcost/costTypesList";
		public static final String costView				= "/zjgxcost/costView";
		public static final String demandTypesList1		= "/zjgxdemand1/demandTypesList1";
		public static final String demandView1			= "/zjgxdemand1/demandView1";
		public static final String demandCreate			= "/zjgxdemand/demandCreate";
		public static final String fansAdd1				= "/customer1/fansAdd1";
		public static final String customerView1		= "/customer1/customerView1";
		public static final String zixunList1			= "/zjgxzixun1/zixunList1";
		public static final String zixunView1			= "/zjgxzixun1/zixunView1";
	}
	
	public static final class task {
		public static final int index				= 1001;
		public static final int login				= 1002;
		public static final int register            = 1000;
		public static final int logout				= 1003;
		public static final int faceView			= 1004;
		public static final int faceList			= 1005;
		public static final int news3List			= 1006;
		public static final int news3View			= 1007;
		public static final int news3Create			= 1008;
		public static final int commentList		    = 1009;
		public static final int commentCreate		= 1010;
		public static final int customerView		= 1011;
		public static final int customerEdit		= 1012;
		public static final int fansAdd				= 1013;
		public static final int fansDel				= 1014;
		public static final int notice				= 1015;
		public static final int news3Collect		= 1016;
		public static final int news3CollectList    = 1017; 
		public static final int news3TypesList      = 1018;  
		public static final int news3Types          = 1019;
		public static final int newsnoticeAdd		= 1020;
		public static final int demandTypesList		= 1021;
		public static final int demandView			= 1022;
		public static final int enterpriseList		= 1023;
		public static final int costTypesList		= 1024;
		public static final int costView			= 1025;
		public static final int demandTypesList1	= 1026;
		public static final int demandView1			= 1027;
		public static final int demandCreate		= 1028;
		public static final int demandList			= 1029;
		public static final int fansAdd1			= 1030;
		public static final int customerView1		= 1031;
		public static final int zixunList1			= 1032;
		public static final int zixunView1			= 1033;
	}
	
	public static final class err {
		public static final String network			= "网络出错了！请检查你的网络";
		public static final String message			= "消息错误";
		public static final String jsonFormat		= "消息格式错误";
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// intent & action settings
	
	public static final class intent {
		public static final class action {
			public static final String EDITTEXT		= "com.zjgx.zixun.EDITTEXT";
			public static final String EDITNEWS		= "com.zjgx.zixun.EDITNEWS";
			public static final String EDITUSER		= "com.zjgx.zixun.EDITUSER";
		}
	}
	
	public static final class action {
		public static final class edittext {
			public static final int CONFIGSIGN		= 2001;
			public static final int CONFIGNAME      = 2002;
			public static final int CONFIGPASS      = 2003;
			public static final int COMMENT			= 2004;
			public static final int COLLECT         = 2005;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// additional settings
	
	public static final class web {
		public static final String base				= "http://map.njibi.com.cn";
		public static final String gomap			= base + "/gomap.php";
	}
}