package com.zjgx.zixun.base;

import android.app.Application;

public class BaseApp extends Application {
	
	private String s;
	private long l;
	private int i;
	
	public int getInt () {
		return i;
	}
	
	public void setInt (int i) {
		this.i = i;
	}
	
	public long getLong () {
		return l;
	}
	
	public void setLong (long l) {
		this.l = l;
	}
	
	public String getString () {
		return s;
	}
	
	public void setString (String s) {
		this.s = s;
	}
}