package com.zjgx.zixun.guest.ui;

import android.content.Intent;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.BaseGuestUiWeb;
import com.zjgx.zixun.guest.base.GuestC;

public class UiIndex2_4 extends BaseGuestUiWeb {
	
	private WebView mWebViewMap;
	
	@Override
	public void onStart() {
		super.onStart();
		
		setContentView(R.layout.guest_main_layout);
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_3);
		ib.setImageResource(R.drawable.guest_top3_2);
				
		mWebViewMap = (WebView) findViewById(R.id.web_map);
		mWebViewMap.getSettings().setJavaScriptEnabled(true);
		mWebViewMap.setWebViewClient(new WebViewClient(){
		
		});
		mWebViewMap.loadUrl(GuestC.web.manage4);
		
		this.setWebView(mWebViewMap);
		this.startWebView();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebViewMap.canGoBack()) {
			mWebViewMap.goBack();
			return true;
			}else if (keyCode == KeyEvent.KEYCODE_BACK) {
				Intent intent = new Intent(UiIndex2_4.this,UiIndex2.class);
				startActivity(intent);
				this.finish();
				return true;
				} else {
					return super.onKeyDown(keyCode, event);
					}
		}
}