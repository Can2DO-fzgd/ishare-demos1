package com.zjgx.zixun.guest.ui;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.BaseGuestUiAuth;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class UiIndex1 extends BaseGuestUiAuth {
			
	private int[] idarr = new int[]{R.id.tv1,R.id.tv2,R.id.tv3,R.id.tv4,R.id.tv5,R.id.tv6,R.id.tv7,R.id.tv8};
	private int[] colorarr = new int[]{0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF};
	private int[] bgarr = new int[]{0xFFFF6666,0xFF1e67c0,0xFFd47756,0xFF5a626f,0xFFee7434,0xFF3eadeb,0xFF0385fd,0xFF00a179};
	private String[] textarr = new String[]{"推荐产品","最新产品","产品排行","科技领域","文化领域","生活领域","环保领域","更多领域"};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_guest_zixun_list);
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.guest_top1_2);
		if (textarr.length < 7){
		for(int i=0;i<textarr.length;i++){
			TextView tv = (TextView)findViewById(idarr[i]);
			tv.setText(textarr[i]);
			tv.setBackgroundColor(bgarr[i]);
			tv.setTextColor(colorarr[i]);
			tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					TextView t = (TextView)v;
					switch (v.getId()) {
					case R.id.tv1:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_1.class);
						break;
					case R.id.tv2:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_2.class);
						break;
					case R.id.tv3:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_3.class);
						break;
					case R.id.tv4:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_4.class);
						break;
					case R.id.tv5:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_5.class);
						break;
					case R.id.tv6:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_6.class);
						break;
					case R.id.tv7:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex1_7.class);
						break;
					}
					}
				});
			}
		}
		if (textarr.length-1 > 6){
			for(int i=0;i<textarr.length-1;i++){
				TextView tv = (TextView)findViewById(idarr[i]);
				tv.setText(textarr[i]);
				tv.setBackgroundColor(bgarr[i]);
				tv.setTextColor(colorarr[i]);
				tv.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						TextView t = (TextView)v;
						switch (v.getId()) {
						case R.id.tv1:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_1.class);
							break;
						case R.id.tv2:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_2.class);
							break;
						case R.id.tv3:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_3.class);
							break;
						case R.id.tv4:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_4.class);
							break;
						case R.id.tv5:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_5.class);
							break;
						case R.id.tv6:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_6.class);
							break;
						case R.id.tv7:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiIndex1_7.class);
							break;
						}
						}
					});
				}
			
		TextView tv = (TextView)findViewById(idarr[textarr.length-1]);
		tv.setText(textarr[textarr.length-1]);
		tv.setBackgroundColor(bgarr[textarr.length-1]);
		tv.setTextColor(colorarr[textarr.length-1]);
		tv.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				TextView t = (TextView)v;
					showMessage("正在为你加载 : "+t.getText().toString());
					forward(UiIndex1_more1.class);
				}
			});}
		}
	
	private void showMessage(String msg){
		Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
		}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
				this.finish();//getOut();
				return true;
				} else {
					return super.onKeyDown(keyCode, event);
			}
		}
}