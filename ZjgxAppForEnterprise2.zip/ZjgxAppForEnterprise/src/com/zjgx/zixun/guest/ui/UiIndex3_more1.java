package com.zjgx.zixun.guest.ui;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.guest.base.BaseGuestUiAuth;
import com.zjgx.zixun.list.NewsList;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class UiIndex3_more1 extends BaseGuestUiAuth {

	private NewsList newsListAdapter;
	
	private int[] idarr = new int[]{R.id.tv1,R.id.tv2,R.id.tv3,R.id.tv4,R.id.tv5,R.id.tv6,R.id.tv7,R.id.tv8};
	private int[] colorarr = new int[]{0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF};
	private int[] bgarr = new int[]{0xFFFF6666,0xFF1e67c0,0xFFd47756,0xFF5a626f,0xFFee7434,0xFF3eadeb,0xFF0385fd,0xFF00a179};
	private String[] textarr = new String[]{"暂无更多"};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_guest_list_more);
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_4);
		ib.setImageResource(R.drawable.guest_top4_2);
				
		for(int i=0;i<textarr.length;i++){
			TextView tv = (TextView)findViewById(idarr[i]);
			tv.setText(textarr[i]);
			tv.setBackgroundColor(bgarr[i]);
			tv.setTextColor(colorarr[i]);
			tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					TextView t = (TextView)v;
					if(idarr[0] == R.id.tv1){
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiIndex3_1.class);
					}
					}
				});
			}
		}


	private void showMessage(String msg){
		Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
		}
	
	@SuppressWarnings("unused")
	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					newsListAdapter.notifyDataSetChanged();
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiIndex3.class);
		}
		return super.onKeyDown(keyCode, event);
	}
	}