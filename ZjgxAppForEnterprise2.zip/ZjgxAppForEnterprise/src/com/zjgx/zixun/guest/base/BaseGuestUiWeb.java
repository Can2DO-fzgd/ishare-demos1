package com.zjgx.zixun.guest.base;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.ui.UiIndex3;
import com.zjgx.zixun.guest.ui.UiIndex2;
import com.zjgx.zixun.guest.ui.UiIndex1;
import com.zjgx.zixun.guest.ui.UiIndex4;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.webkit.JsResult;

abstract public class BaseGuestUiWeb extends BaseGuestUi {
	
	private static final int MAX_PROGRESS = 100;
	private static final int DIALOG_PROGRESS = 1;
	
	private WebView webView;
	private int mProgress = 0;
	private ProgressDialog mProgressDialog;
	
	public WebView getWebView () {
		return this.webView;
	}
	
	public void setWebView (WebView webView) {
		this.webView = webView;
	}
	
	public void startWebView() {
		
		this.bindMainTop();
		
		webView.setWebChromeClient(new WebChromeClient(){
			@Override
			public void onProgressChanged(WebView view, int progress){
				mProgress = progress;
				mProgressDialog.setProgress(mProgress);
				if (mProgress >= MAX_PROGRESS) {
					mProgressDialog.dismiss();
				}
			}
			
			@Override
            public boolean onJsAlert(WebView view, String url,  
                    String message, final JsResult result) {  
                new AlertDialog.Builder(BaseGuestUiWeb.this)
                    .setTitle("Notification")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, new AlertDialog.OnClickListener() {
                        @Override
						public void onClick(DialogInterface dialog, int which) {
                            result.confirm();
                        }
                    })
                    .setCancelable(false)
                    .create().show();
                return true;
            }
		});
	} 
	
	@Override
	public void onStart() {
		super.onStart();
		
		showDialog(DIALOG_PROGRESS);
		getWindow().requestFeature(Window.FEATURE_PROGRESS);
	} 
	
	@Override
	protected Dialog onCreateDialog(int id){
		switch (id) {
			case DIALOG_PROGRESS:
				mProgressDialog = new ProgressDialog(this);
				mProgressDialog.setTitle("正在努力加载中 ...");
				mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				mProgressDialog.setMax(MAX_PROGRESS);
				return mProgressDialog;
		}
		return null;
	}
	
	@Override
	protected void onPause() {
		webView.stopLoading();
		super.onPause();
	}
	
	private void bindMainTop () {
		ImageButton bTopZixun = (ImageButton) findViewById(R.id.main_top_1);
		ImageButton bTopFashion = (ImageButton) findViewById(R.id.main_top_2);
		ImageButton bTopContent = (ImageButton) findViewById(R.id.main_top_3);
		ImageButton bTopAbout = (ImageButton) findViewById(R.id.main_top_4);
		if (bTopZixun != null && bTopFashion != null && bTopContent != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
					case R.id.main_top_1:
						forward(UiIndex1.class);
						break;
					case R.id.main_top_2:
						forward(UiIndex4.class);
						break;
					case R.id.main_top_3:
						forward(UiIndex2.class);
						break;
					case R.id.main_top_4:
						forward(UiIndex3.class);
						break;
					}
				}
			};
			bTopZixun.setOnClickListener(mOnClickListener);
			bTopFashion.setOnClickListener(mOnClickListener);
			bTopContent.setOnClickListener(mOnClickListener);
			bTopAbout.setOnClickListener(mOnClickListener);
		}
	}
}