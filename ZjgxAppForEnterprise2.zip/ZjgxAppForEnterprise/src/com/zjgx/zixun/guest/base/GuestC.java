package com.zjgx.zixun.guest.base;

public final class GuestC {

	////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static final class web {
		/////////////////////////////////////平台产品/////////////////////////////////////////////////
		public static final String product			= "http://www.can2do.com:811";
		public static final String types1			= product + "/recommend";
		public static final String types2			= product + "/new";
		public static final String types3			= product + "/hot";
		public static final String types4			= product + "/product/explore/types1";
		public static final String types5			= product + "/product/explore/types2";
		public static final String types6			= product + "/product/explore/types3";
		public static final String types7			= product + "/product/explore/types4";
		public static final String types8			= product + "/product/explore/more";
		public static final String types9			= product + "/product/explore/moretype1";
		public static final String types10			= product + "/search";
		////////////////////////////////////时尚应用///////////////////////////////////////////////////
		public static final String manage1			= product + "/login";
		public static final String manage2			= product + "/register";
		public static final String manage3			= product + "/tag";
		public static final String manage4			= product + "/article";
		public static final String manage5			= product + "/my/teaching/courses";
		public static final String manage6			= product + "/settings/";
		public static final String manage7			= product + "/admin/";
		public static final String manage8			= product + "/notification";
		public static final String manage9			= product + "/message/";
		public static final String manage10			= product + "/message/send/";
		public static final String manage11			= product + "/merchant";
		public static final String manage12			= product + "/logout";
		//////////////////////////////////关于我们/////////////////////////////////////////////////////
		public static final String about1			= product + "/page/aboutus";
		public static final String about2			= product + "/page/questions";
	}
}