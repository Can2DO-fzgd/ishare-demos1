package com.zjgx.zixun.guest.base;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.ui.UiIndex3;
import com.zjgx.zixun.guest.ui.UiIndex2;
import com.zjgx.zixun.guest.ui.UiIndex1;
import com.zjgx.zixun.guest.ui.UiIndex4;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class BaseGuestUiAuth extends BaseGuestUi {
	
	@Override
	public void onStart() {
		super.onStart();
		
		this.bindMainTop();
	}
	
	private void bindMainTop () {
		ImageButton bTopZixun = (ImageButton) findViewById(R.id.main_top_1);
		ImageButton bTopFashion = (ImageButton) findViewById(R.id.main_top_2);
		ImageButton bTopContent = (ImageButton) findViewById(R.id.main_top_3);
		ImageButton bTopAbout = (ImageButton) findViewById(R.id.main_top_4);
		if (bTopZixun != null && bTopFashion != null && bTopContent != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.main_top_1:
							forward(UiIndex1.class);
							break;
						case R.id.main_top_2:
							forward(UiIndex4.class);
							break;
						case R.id.main_top_3:
							forward(UiIndex2.class);
							break;
						case R.id.main_top_4:
							forward(UiIndex3.class);
							break;
					}
				}
			};
			bTopZixun.setOnClickListener(mOnClickListener);
			bTopFashion.setOnClickListener(mOnClickListener);
			bTopContent.setOnClickListener(mOnClickListener);
			bTopAbout.setOnClickListener(mOnClickListener);
		}
	}
}