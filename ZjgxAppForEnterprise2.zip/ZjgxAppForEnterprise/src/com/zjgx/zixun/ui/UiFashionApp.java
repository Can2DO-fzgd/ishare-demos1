package com.zjgx.zixun.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.BaseUiAuth;
import com.zjgx.zixun.guest.ui.UiIndex1;
import com.zjgx.zixun.list.NewsList;

public class UiFashionApp extends BaseUiAuth {

	private NewsList newsListAdapter;
	private GridView gridview;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_fashion_app);
		//SysApplication.getInstance().addActivity(this);
		//SysApplication.getInstance().addActivity(this);
		
		// set handler
		this.setHandler(new IndexHandler(this));

		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_4);
		ib.setImageResource(R.drawable.top_fashion_2);

		List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
		
		//types1-特区微博
		Map<String, Object> item1 = new HashMap<String, Object>();
		item1.put("imageItem", R.drawable.fashionapp_types1);
		item1.put("textItem", "");
		items.add(item1);
		
		//types2-特区微信
		Map<String, Object> item2 = new HashMap<String, Object>();
		item2.put("imageItem", R.drawable.fashionapp_types2);
		item2.put("textItem", "");
		items.add(item2);
		
		//types3-园区论坛
		Map<String, Object> item3 = new HashMap<String, Object>();
		item3.put("imageItem", R.drawable.fashionapp_types3);
		item3.put("textItem", "");
		items.add(item3);
		
		//types4-园区地图
		Map<String, Object> item4 = new HashMap<String, Object>();
		item4.put("imageItem", R.drawable.fashionapp_types4);
		item4.put("textItem", "");
		items.add(item4);	
		
		//types5-园区邮箱-微博平台
		Map<String, Object> item5 = new HashMap<String, Object>();
		item5.put("imageItem", R.drawable.fashionapp_types5);
		item5.put("textItem", "");
		items.add(item5);
						
		//types6-会议预定
		Map<String, Object> item6 = new HashMap<String, Object>();
		item6.put("imageItem", R.drawable.fashionapp_types6);
		item6.put("textItem", "");
		items.add(item6);
		
		// 实例化一个适配器
		SimpleAdapter adapter = new SimpleAdapter(this, items,
				R.layout.grid_item, new String[] { "imageItem", "textItem" },
				new int[] { R.id.image_item, R.id.text_item });
		
		// 获得GridView实例
		gridview = (GridView) findViewById(R.id.mygridview);
		
		// 将GridView和数据适配器关联
		gridview.setAdapter(adapter);
		
		// 点击跳转事件
		gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				switch (arg2) {
				case 0:
					forward(UiTypesTwelve.class);//特区微博
					break;
				case 1:
					forward(UiTypesTwelve.class);//特区微信
					break;
				case 2:
					forward(UiTypesTwelve.class);//园区论坛
					break;
				case 3:
					forward(UiTypesTwelve.class);//园区地图
					break;
				case 4:
					forward(UiTypesTwelve.class);//园区邮箱
					break;
				case 5:
					forward(UiTypesTwelve.class);//会议预定
					break;
				}
			}
		});
	}

	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					newsListAdapter.notifyDataSetChanged();
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiIndex1.class);
		}
		return super.onKeyDown(keyCode, event);
	}
}