package com.zjgx.zixun.model;

import com.zjgx.zixun.base.BaseModel;

public class Zixun extends BaseModel {
	
	// model columns
	public final static String COL_ID = "id";
	public final static String COL_FACE = "face";
	public final static String COL_DESC = "desc";
	public final static String COL_NAME = "name";
	public final static String COL_CTYPE = "ctype";
	public final static String COL_AUTHOR = "author";
	public final static String COL_CONTENT = "content";
	public final static String COL_COMMENT = "comment";
	public final static String COL_UPTIME = "uptime";
	
	private String id;
	private String face;
	private String desc;
	private String name;
	private String ctype;
	private String author;
	private String content;
	private String comment;
	private String uptime;
	
	public Zixun () {}
	
	public String getId () {
		return this.id;
	}
	
	public void setId (String id) {
		this.id = id;
	}
	
	public String getFace () {
		return this.face;
	}
	
	public void setFace (String face) {
		this.face = face;
	}
	
	public String getDesc () {
		return this.desc;
	}
	
	public void setDesc (String desc) {
		this.desc = desc;
	}
	
	public String getName () {
		return this.name;
	}
	
	public void setName (String name) {
		this.name = name;
	}
	
	public String getCtype () {
		return this.ctype;
	}
	
	public void setCtype (String ctype) {
		this.ctype = ctype;
	}
	
	public String getAuthor () {
		return this.author;
	}
	
	public void setAuthor (String author) {
		this.author = author;
	}
	
	public String getContent () {
		return this.content;
	}
	
	public void setContent (String content) {
		this.content = content;
	}
	
	public String getComment () {
		return this.comment;
	}
	
	public void setComment (String comment) {
		this.comment = comment;
	}
	
	public String getUptime () {
		return this.uptime;
	}
	
	public void setUptime (String uptime) {
		this.uptime = uptime;
	}
}