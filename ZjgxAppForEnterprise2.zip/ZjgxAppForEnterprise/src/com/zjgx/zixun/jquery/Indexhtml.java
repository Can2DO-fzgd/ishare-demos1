package com.zjgx.zixun.jquery;

import org.apache.cordova.DroidGap;
import android.os.Bundle;

public class Indexhtml extends DroidGap {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.loadUrl("http://www.can2do.com:811");
    }
}