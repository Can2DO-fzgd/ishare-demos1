package com.can2do.ishare.tab;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.zjgx.zixun.R;
import com.can2do.ishare.base.GuestC;
import com.can2do.ishare.jquery.Indexhtml1;
import com.can2do.ishare.jquery.Indexhtml2;
import com.can2do.ishare.jquery.Indexhtml3;

public class Ui_Fragment3 extends Fragment {

	@Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		
        this.getView().findViewById(R.id.share_btn1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share1);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share1, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share2);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share2, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share3);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share3, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share4);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share4, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share5);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share5, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share6);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share6, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share7);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share7, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share8);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share8, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share9);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share9, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share10);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share10, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn11).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share11);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share11, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.share_btn12).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                 
                Intent in=new Intent(getActivity(),Indexhtml3.class);
                in.putExtra("url", GuestC.web.share12);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.share12, Toast.LENGTH_SHORT).show();
            }
        });
        
    }
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflateAndSetupView(inflater, container, savedInstanceState, R.layout.ui_tab_fragment3);
	}
	
	private View inflateAndSetupView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState, int layoutResourceId) {
		View layout = inflater.inflate(layoutResourceId, container, false);
		
		return layout;
	} 
}
