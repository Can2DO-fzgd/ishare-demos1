package com.can2do.ishare.tab;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.zjgx.zixun.R;
import com.can2do.ishare.base.GuestC;
import com.can2do.ishare.jquery.Indexhtml1;
import com.can2do.ishare.jquery.Indexhtml2;

public class Ui_Fragment2 extends Fragment {

	@Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		
//        this.getView().findViewById(R.id.clickme).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                EditText editText = (EditText) activity.mFragment2.getView().findViewById(R.id.edit);
//                Toast.makeText(activity, editText.getText(), Toast.LENGTH_SHORT).show();
//            }
//        });
        
        
        this.getView().findViewById(R.id.app_btn1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                Intent in=new Intent(getActivity(),Indexhtml2.class);
                in.putExtra("url", GuestC.web.app1);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.app1, Toast.LENGTH_SHORT).show();
            }
        });
        
        this.getView().findViewById(R.id.app_btn2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ��ð󶨵�FragmentActivity
                Ui_Main activity = ((Ui_Main)getActivity());
                // ���TabAFm�Ŀؼ�
                Intent in=new Intent(getActivity(),Indexhtml2.class);
                in.putExtra("url", GuestC.web.app2);
                startActivity(in);
                //Toast.makeText(activity, GuestC.web.app2, Toast.LENGTH_SHORT).show();
            }
        });
        
//        this.getView().findViewById(R.id.app_btn3).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app3);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app3, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn4).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app4);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app4, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        
//        this.getView().findViewById(R.id.app_btn5).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app5);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app5, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn6).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app6);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app6, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn7).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app7);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app7, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn8).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app8);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app8, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn9).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app9);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app9, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn10).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app10);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app10, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn11).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app11);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app11, Toast.LENGTH_SHORT).show();
//            }
//        });
//        
//        this.getView().findViewById(R.id.app_btn12).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // ��ð󶨵�FragmentActivity
//                Ui_Main activity = ((Ui_Main)getActivity());
//                // ���TabAFm�Ŀؼ�
//                Intent in=new Intent(getActivity(),Indexhtml2.class);
//                in.putExtra("url", GuestC.web.app12);
//                startActivity(in);
//                //Toast.makeText(activity, GuestC.web.app12, Toast.LENGTH_SHORT).show();
//            }
//        });
        
        
        
    }
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflateAndSetupView(inflater, container, savedInstanceState, R.layout.ui_tab_fragment2);
	}
	
	private View inflateAndSetupView(LayoutInflater inflater, ViewGroup container, 
			Bundle savedInstanceState, int layoutResourceId) {
		View layout = inflater.inflate(layoutResourceId, container, false);
		
		return layout;
	} 
}
