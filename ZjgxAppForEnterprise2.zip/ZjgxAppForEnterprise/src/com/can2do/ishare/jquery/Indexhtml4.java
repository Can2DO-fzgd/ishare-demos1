package com.can2do.ishare.jquery;

import org.apache.cordova.DroidGap;

import com.zjgx.zixun.R;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;

//public class Indexhtml4 extends DroidGap {
//	private String url = "";
//	private String urlStr;
//	
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        
//        Intent intent = this.getIntent();
//		urlStr = intent.getStringExtra("url");
//		url=urlStr;
//		
//        super.loadUrl(url);
//    }
//}


public class Indexhtml4 extends DroidGap {
	
	private String url = "";
	private String urlStr;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.setIntegerProperty("splashscreen", R.drawable.load);

		Intent intent = this.getIntent();
		urlStr = intent.getStringExtra("url");
		url=urlStr;
		
		ConnectivityManager cwjManager=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = cwjManager.getActiveNetworkInfo();
		if (info != null && info.isAvailable()){
			super.loadUrl(url,4500);
			}
		else {
			super.loadUrl("file:///android_asset/www/index.html", 4500);
			}
	}
}