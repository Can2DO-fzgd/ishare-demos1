/** Automatically generated file. DO NOT MODIFY */
package com.zjgx.zixun;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}