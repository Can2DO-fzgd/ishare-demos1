package com.zjgx.zixun.parkabout;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.ui.UiGuestContentUsList;
import android.app.Activity;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher.ViewFactory;

public class UiGuestParkLandscape extends Activity {
	int[] images=new int[]{
			R.drawable.fengjin_1,R.drawable.fengjin_2,R.drawable.fengjin_3,
			R.drawable.fengjin_4,R.drawable.fengjin_5,R.drawable.fengjin_6,R.drawable.fengjin_7
//			R.drawable.fengjin_8,R.drawable.fengjin_9,R.drawable.fengjin_10,R.drawable.fengjin_11,
//			R.drawable.fengjin_12,R.drawable.fengjin_13,R.drawable.fengjin_14,R.drawable.fengjin_15,
//			R.drawable.fengjin_16,R.drawable.fengjin_17,R.drawable.fengjin_18,R.drawable.fengjin_19,
//			R.drawable.fengjin_20	
	};
	private Button goBack;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_park_landscape);
		
		// tab button
//		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_3);
//		ib.setImageResource(R.drawable.guest_top3_2);
		
		goBack=(Button)findViewById(R.id.goBack);
		goBack.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(UiGuestParkLandscape.this,UiGuestContentUsList.class);
				startActivity(intent);
				finish();				
			}
		});
		
		 final Gallery gallery = (Gallery) findViewById(R.id.gallery);	
			final ImageSwitcher switcher = (ImageSwitcher)findViewById(R.id.park_landscape_img);		
			switcher.setFactory(new ViewFactory(){		
				@Override
				public View makeView(){
					ImageView imageView = new ImageView(UiGuestParkLandscape.this);
					imageView.setBackgroundColor(0xff0000);
					imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
					imageView.setLayoutParams(new ImageSwitcher.LayoutParams(
						LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
					return imageView;
				}
			});		
			switcher.setInAnimation(AnimationUtils.loadAnimation(this,
				android.R.anim.fade_in));
			switcher.setOutAnimation(AnimationUtils.loadAnimation(this,
				android.R.anim.fade_out));		
			BaseAdapter adapter = new BaseAdapter(){			
				@Override
				public int getCount(){
					return Integer.MAX_VALUE;
					//return images.length;
				}			
				@Override
				public Object getItem(int position){
					return position;
				}
				@Override
				public long getItemId(int position){
					return position;
				}
				@Override
				public View getView(int position, View convertView, ViewGroup parent){
					
					ImageView imageView = new ImageView(UiGuestParkLandscape.this);
					imageView
						.setImageResource(images[position % images.length]);
					
					imageView.setScaleType(ImageView.ScaleType.FIT_XY);
					imageView.setLayoutParams(new Gallery.LayoutParams(75, 100));
					TypedArray typedArray = obtainStyledAttributes(
						R.styleable.Gallery);
					imageView.setBackgroundResource(typedArray.getResourceId(
						R.styleable.Gallery_android_galleryItemBackground, 0));
					return imageView;
				}
			};
			gallery.setAdapter(adapter);
			gallery.setOnItemSelectedListener(new OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int position, long id) {
					switcher.setImageResource(images[position%images.length]);
					
				}
				@Override
				public void onNothingSelected(AdapterView<?> arg0) {				
					
				}			
			});
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(UiGuestParkLandscape.this,UiGuestContentUsList.class);
			startActivity(intent);
			this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
