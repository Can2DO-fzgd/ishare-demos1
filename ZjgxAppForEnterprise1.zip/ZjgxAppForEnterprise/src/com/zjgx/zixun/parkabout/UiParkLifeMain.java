﻿package com.zjgx.zixun.parkabout;


import com.zjgx.zixun.R;
import com.zjgx.zixun.ui.UiIndex;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class UiParkLifeMain extends Activity {
	private Button floor_map_butt, park_landscape_butt, guide_in_park_butt, goBack;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_park_life_main);
		floor_map_butt = (Button) findViewById(R.id.floor_map_butt);
		park_landscape_butt = (Button) findViewById(R.id.park_landscape_butt);
		guide_in_park_butt = (Button) findViewById(R.id.guide_in_park_butt);
		goBack = (Button) findViewById(R.id.goBack);
		myOnClickListener myListener=new myOnClickListener();
		floor_map_butt.setOnClickListener(myListener);
		park_landscape_butt.setOnClickListener(myListener);
		guide_in_park_butt.setOnClickListener(myListener);
		goBack.setOnClickListener(myListener);
	}

	private class myOnClickListener implements OnClickListener {
		Intent intent=null;
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.floor_map_butt:
				intent=new Intent(UiParkLifeMain.this,UiFloorMap.class);
				break;
			case R.id.park_landscape_butt:
				intent=new Intent(UiParkLifeMain.this,UiParkLandscape.class);
				break;
			case R.id.guide_in_park_butt:
				intent=new Intent(UiParkLifeMain.this,UiGuideInPark.class);
				break;
			case R.id.goBack:
				intent=new Intent(UiParkLifeMain.this,UiIndex.class);
				break;

			default:
				break;
			}
			startActivity(intent);
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(UiParkLifeMain.this,UiIndex.class);
			startActivity(intent);
			this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
