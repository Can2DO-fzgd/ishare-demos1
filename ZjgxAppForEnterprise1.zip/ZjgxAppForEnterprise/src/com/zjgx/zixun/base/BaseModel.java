package com.zjgx.zixun.base;

public class BaseModel {
	
}