package com.zjgx.zixun.base;

import com.zjgx.zixun.model.Customer;

public class BaseAuth {
	
	static public boolean isLogin () {
		Customer customer = Customer.getInstance();
		if (customer.getLogin() == true) {
			return true;
		}
		return false;
	}
	
	static public void setLogin (Boolean status) {
		Customer customer = Customer.getInstance();
		customer.setLogin(status);
	}
	
	static public void setRegister(Boolean status){
		Customer customer = Customer.getInstance();
		customer.setRegister(status);
	}
	
	static public void setCustomer (Customer mc) {
		Customer customer = Customer.getInstance();
		customer.setId(mc.getId());
		customer.setSid(mc.getSid());
		customer.setUsername(mc.getUsername());
		customer.setSign(mc.getSign());
		customer.setFace(mc.getFace());
	}
	
	static public Customer getCustomer () {
		return Customer.getInstance();
	}
}