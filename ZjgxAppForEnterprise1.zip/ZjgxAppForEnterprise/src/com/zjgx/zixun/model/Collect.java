package com.zjgx.zixun.model;

import com.zjgx.zixun.base.BaseModel;

public class Collect extends BaseModel {
	
	// model columns
	public final static String COL_ID = "id";
	public final static String COL_NEWSID = "newsid";
	public final static String COL_CONTENT = "content";
	public final static String COL_UPTIME = "uptime";
	
	private String id;
	private String newsid;
	private String content;
	private String uptime;
	
	public Collect () {}
	
	public String getId () {
		return this.id;
	}
	
	public void setId (String id) {
		this.id = id;
	}
	
	public String getNewsid () {
		return this.newsid;
	}
	
	public void setNewsid (String newsid) {
		this.newsid = newsid;
	}
	
	public String getContent () {
		return this.content;
	}
	
	public void setContent (String content) {
		this.content = content;
	}
	
	public String getUptime () {
		return this.uptime;
	}
	
	public void setUptime (String uptime) {
		this.uptime = uptime;
	}
}