package com.zjgx.zixun.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseMessage;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.BaseUiAuth;
import com.zjgx.zixun.base.C;
import com.zjgx.zixun.list.NewsList;
import com.zjgx.zixun.model.Zixun;
import com.zjgx.zixun.sqlite.NewsSqlite;

public class UiTypesTwelve extends BaseUiAuth{
	private ListView newsListView;
	private NewsList newsListAdapter;
	private NewsSqlite newsSqlite;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zx_zixun_type_list);
		
		// set handler
		this.setHandler(new IndexHandler(this));
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);
		
		// init sqlite
		newsSqlite = new NewsSqlite(this);		
	}
	
	@Override
	public void onStart(){
		super.onStart();
		
		// show all news list
		HashMap<String, String> newsParams = new HashMap<String, String>();
		newsParams.put("typeId", "0");
		newsParams.put("pageId", "1");
		newsParams.put("pageCount", "10");
		newsParams.put("ctype", "2");
		this.doTaskAsync(C.task.demandTypesList1, C.api.demandTypesList1, newsParams);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
			case C.task.demandTypesList1:
				try {
					@SuppressWarnings("unchecked")
					final ArrayList<Zixun> newsList = (ArrayList<Zixun>) message.getResultList("Zixun");
					// load face image
					for (Zixun news : newsList) {
						loadImage(news.getFace());
						newsSqlite.updateNews(news);
					}
					// show text
					newsListView = (ListView) this.findViewById(R.id.app_index_list_view);
					newsListAdapter = new NewsList(this, newsList);
					newsListView.setAdapter(newsListAdapter);
					newsListView.setOnItemClickListener(new OnItemClickListener(){
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
							Bundle params = new Bundle();
							params.putString("newsId", newsList.get(pos).getId());
							params.putString("name", newsList.get(pos).getName());
							params.putString("content", newsList.get(pos).getContent());
							params.putString("ctype", newsList.get(pos).getCtype());
							overlay(UiDemand1.class, params);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
		}
	}
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
		toast(C.err.network);
		switch (taskId) {
			case C.task.demandTypesList1:
				try {
					final ArrayList<Zixun> newsList = newsSqlite.getAllNews();
					// load face image
					for (Zixun news : newsList) {
						loadImage(news.getFace());
						newsSqlite.updateNews(news);
					}
					// show text
					newsListView = (ListView) this.findViewById(R.id.app_index_list_view);
					newsListAdapter = new NewsList(this, newsList);
					newsListView.setAdapter(newsListAdapter);
					newsListView.setOnItemClickListener(new OnItemClickListener(){
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
							Bundle params = new Bundle();
							params.putString("newsId", newsList.get(pos).getId());
							overlay(UiDemand1.class, params);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiMoveOa.class);
		}
		return super.onKeyDown(keyCode, event);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes
	
	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
					case BaseTask.LOAD_IMAGE:
						newsListAdapter.notifyDataSetChanged();
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}