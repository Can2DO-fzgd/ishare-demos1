package com.zjgx.zixun.ui;

import java.util.HashMap;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseMessage;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.BaseUiAuth;
import com.zjgx.zixun.base.C;
import com.zjgx.zixun.model.Customer;
import com.zjgx.zixun.model.Zixun;
import com.zjgx.zixun.util.AppCache;
import com.zjgx.zixun.util.AppFilter;
import com.zjgx.zixun.util.UIUtil;

@SuppressLint("CutPasteId")
public class UiNews2 extends BaseUiAuth {

	private String newsId = null;
	private String customerId = null;
	private Button addfansBtn = null;
	private ImageView faceImage = null;
	private String faceImageUrl = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_news1);

		// set handler
		this.setHandler(new NewsHandler(this));

		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_2);
		ib.setImageResource(R.drawable.top_mysite_2);
				
		// get params
		Bundle params = this.getIntent().getExtras();
		newsId = params.getString("newsId");

		// do add fans
		addfansBtn = (Button) this.findViewById(R.id.app_news_btn_addfans);
		addfansBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// prepare news data
				HashMap<String, String> urlParams = new HashMap<String, String>();
				urlParams.put("customerId", customerId);
				urlParams.put("message", "有人关注你了！");
				doTaskAsync(C.task.fansAdd, C.api.fansAdd, urlParams);
			}
		});

		// prepare news data
		HashMap<String, String> newsParams = new HashMap<String, String>();
		newsParams.put("newsId", newsId);
		this.doTaskAsync(C.task.demandView, C.api.demandView, newsParams);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods

	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
		case C.task.demandView:
			try {
				Zixun news = (Zixun) message.getResult("Zixun");
				TextView textUptime = (TextView) this
						.findViewById(R.id.app_news_text_uptime);
				TextView textTitle = (TextView) this
						.findViewById(R.id.app_news_text_title);
				TextView textContent = (TextView) this
						.findViewById(R.id.app_news_text_content);
				textUptime.setText(news.getUptime());
				textTitle.setText(AppFilter.getHtml(news.getName()));
				textContent.setText(AppFilter.getHtml(news.getContent()));
				Customer customer = (Customer) message.getResult("Customer");
				TextView textCustomerName = (TextView) this
						.findViewById(R.id.app_news_text_customer_name);
				TextView testCustomerInfo = (TextView) this
						.findViewById(R.id.app_news_text_customer_info);
				textCustomerName.setText(customer.getSign());
				testCustomerInfo
						.setText(UIUtil.getCustomerInfo(this, customer));
				// set customer id
				customerId = customer.getId();
				// load face image async
				faceImage = (ImageView) this
						.findViewById(R.id.app_news_image_face);
				faceImageUrl = customer.getFaceurl();
				loadImage(faceImageUrl);
			} catch (Exception e) {
				e.printStackTrace();
				toast(e.getMessage());
			}
			break;
		case C.task.fansAdd:
			if (message.getCode().equals("10000")) {
				toast("关注成功！");
				// refresh customer data
				HashMap<String, String> cvParams = new HashMap<String, String>();
				cvParams.put("customerId", customerId);
				this.doTaskAsync(C.task.customerView, C.api.customerView,cvParams);
			} else {
				toast("关注失败！可能你已经关注了他");
			}
			break;
		case C.task.customerView:
			try {
				// update customer info
				final Customer customer = (Customer) message
						.getResult("Customer");
				TextView textInfo = (TextView) this
						.findViewById(R.id.app_news_text_customer_info);
				textInfo.setText(UIUtil.getCustomerInfo(this, customer));
			} catch (Exception e) {
				e.printStackTrace();
				toast(e.getMessage());
			}
			break;
		}
	}

	@Override
	public void onNetworkError(int taskId) {
		super.onNetworkError(taskId);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// other methods

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			doFinish();
		}
		return super.onKeyDown(keyCode, event);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes

	@SuppressLint("HandlerLeak")
	private class NewsHandler extends BaseHandler {
		public NewsHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					Bitmap face = AppCache.getImage(faceImageUrl);
					faceImage.setImageBitmap(face);
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}