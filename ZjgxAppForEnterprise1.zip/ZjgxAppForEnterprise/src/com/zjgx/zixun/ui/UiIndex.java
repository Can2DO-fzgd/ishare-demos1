package com.zjgx.zixun.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;

import com.zjgx.zixun.guest.ui.UiGuestZixunList;
import com.zjgx.zixun.guest.ui.UiMySiteCompanyList;
import com.zjgx.zixun.guest.ui.UiMySiteServerList;
import com.zjgx.zixun.guest.ui.UiZixunProductList;
import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.BaseUiAuth;
import com.zjgx.zixun.list.NewsList;

public class UiIndex extends BaseUiAuth {

	private NewsList newsListAdapter;
	private GridView gridview;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_index);
		
		// set handler
		this.setHandler(new IndexHandler(this));

		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_3);
		ib.setImageResource(R.drawable.top_zixun_2);

		List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
		
		//types1-特区公告
		Map<String, Object> item1 = new HashMap<String, Object>();
		item1.put("imageItem", R.drawable.news_types1);
		item1.put("textItem", "");
		items.add(item1);
		
		//types2-特区新闻
		Map<String, Object> item2 = new HashMap<String, Object>();
		item2.put("imageItem", R.drawable.news_types2);
		item2.put("textItem", "");
		items.add(item2);
		
		//types3-政策
		Map<String, Object> item3 = new HashMap<String, Object>();
		item3.put("imageItem", R.drawable.news_types3);
		item3.put("textItem", "");
		items.add(item3);
		
		//types4-发文
		Map<String, Object> item4 = new HashMap<String, Object>();
		item4.put("imageItem", R.drawable.news_types4);
		item4.put("textItem", "");
		items.add(item4);
		
		//types5-特区荣誉
		Map<String, Object> item5 = new HashMap<String, Object>();
		item5.put("imageItem", R.drawable.news_types5);
		item5.put("textItem", "");
		items.add(item5);
		
		//types6-媒体报道
		Map<String, Object> item6 = new HashMap<String, Object>();
		item6.put("imageItem", R.drawable.news_types6);
		item6.put("textItem", "");
		items.add(item6);
		
		//types7-政策解读
		Map<String, Object> item7 = new HashMap<String, Object>();
		item7.put("imageItem", R.drawable.news_types7);
		item7.put("textItem", "");
		items.add(item7);
		
		//types8-材料阅读
		Map<String, Object> item8 = new HashMap<String, Object>();
		item8.put("imageItem", R.drawable.news_types8);
		item8.put("textItem", "");
		items.add(item8);
		
		//types9-优惠政策
		Map<String, Object> item9 = new HashMap<String, Object>();
		item9.put("imageItem", R.drawable.news_types9);
		item9.put("textItem", "");
		items.add(item9);
		
		//types10-人才政策
		Map<String, Object> item10 = new HashMap<String, Object>();
		item10.put("imageItem", R.drawable.news_types10);
		item10.put("textItem", "");
		items.add(item10);
		
		//types11-图片新闻
		Map<String, Object> item11 = new HashMap<String, Object>();
		item11.put("imageItem", R.drawable.news_types11);
		item11.put("textItem", "");
		items.add(item11);
		
		//types12-企业走廊
		Map<String, Object> item12 = new HashMap<String, Object>();
		item12.put("imageItem",R.drawable.news_types12);
		item12.put("textItem", "");
		items.add(item12);
		
		//types13-产品走廊
		Map<String, Object> item13 = new HashMap<String, Object>();
		item13.put("imageItem", R.drawable.news_types13);
		item13.put("textItem", "");
		items.add(item13);
				
		//types14-公共服务
		Map<String, Object> item14 = new HashMap<String, Object>();
		item14.put("imageItem", R.drawable.news_types14);
		item14.put("textItem", "");
		items.add(item14);
		
		// 实例化一个适配器
		SimpleAdapter adapter = new SimpleAdapter(this, items,
				R.layout.grid_item, new String[] { "imageItem", "textItem" },
				new int[] { R.id.image_item, R.id.text_item });
		
		// 获得GridView实例
		gridview = (GridView) findViewById(R.id.mygridview);
		
		// 将GridView和数据适配器关联
		gridview.setAdapter(adapter);
		
		// 点击跳转事件
		gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				switch (arg2) {
				case 0:
					forward(UiGuestNews1.class);//特区公告
					break;
				case 1:
					forward(UiGuestNews2.class);//特区新闻
					break;
				case 2:
					forward(UiGuestNews3.class);//政策公开
					break;
				case 3:
					forward(UiGuestNews4.class);//发文公开
					break;
				case 4:
					forward(UiGuestNews6.class);//特区荣誉
					break;
				case 5:
					forward(UiGuestNews7.class);//媒体报道
					break;
				case 6:
					forward(UiGuestNews8.class);//政策解读
					break;
				case 7:
					forward(UiGuestNews9.class);//材料下载
					break;
				case 8:
					forward(UiGuestNews10.class);//优惠政策
					break;
				case 9:
					forward(UiGuestNews11.class);//人才政策
					break;
				case 10:
					forward(UiGuestNews5.class);//图片新闻
					break;
				case 11:
					forward(UiMySiteCompanyList.class);//企业走廊
					break;
				case 12:
					forward(UiZixunProductList.class);//产品走廊
					break;
				case 13:
					forward(UiMySiteServerList.class);//公共服务
					break;
				}
			}
		});
	}

	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					newsListAdapter.notifyDataSetChanged();
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiGuestZixunList.class);
		}
		return super.onKeyDown(keyCode, event);
	}
}