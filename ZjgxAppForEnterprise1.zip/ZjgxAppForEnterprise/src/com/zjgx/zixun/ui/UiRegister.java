package com.zjgx.zixun.ui;

import java.util.HashMap;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseMessage;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.C;

public class UiRegister extends BaseUi {

	private EditText rEditName;
	private EditText rEditPass;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// set view after check Register
		setContentView(R.layout.ui_register);
		
		// remember password
		rEditName = (EditText) this.findViewById(R.id.app_register_edit_name);
		rEditPass = (EditText) this.findViewById(R.id.app_register_edit_pass);
		
		// Register submit
		OnClickListener mOnClickListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (v.getId()) {
					case R.id.app_register_btn_submit : 
						doTaskRegister();
						break;
				}
			}
		};
		findViewById(R.id.app_register_btn_submit).setOnClickListener(mOnClickListener);
	}
	
	private void doTaskRegister() {
		app.setLong(System.currentTimeMillis());
		if (rEditName.length() > 0 && rEditPass.length() > 0) {
			HashMap<String, String> urlParams = new HashMap<String, String>();
			urlParams.put("userName", rEditName.getText().toString());
			urlParams.put("password", rEditPass.getText().toString());
			try {
				this.doTaskAsync(C.task.register, C.api.register, urlParams);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (rEditName.length() == 0){
			toast(this.getString(R.string.msg_userName_isnull));
		} else if(rEditPass.length() == 0) {
			toast(this.getString(R.string.msg_password_isnull));
		} else {
			//toast(this.getString(R.string.msg_password_isnull));
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);
		switch (taskId) {
			case C.task.register:
				toast(this.getString(R.string.msg_registersucces));
				// register complete
				long startTime = app.getLong();
				long RegisterTime = System.currentTimeMillis() - startTime;
				Log.w("RegisterTime", Long.toString(RegisterTime));
				// turn to index
				forward(UiLogin.class);
				break;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// onNetworkError
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiLogin.class);
		}
		return super.onKeyDown(keyCode, event);
	}
}