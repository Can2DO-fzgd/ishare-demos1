package com.zjgx.zixun.guest.ui;

import android.content.Intent;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.Toast;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.BaseGuestUiWeb;
import com.zjgx.zixun.guest.base.GuestC;
//关于我们
public class UiGuestContentAbout extends BaseGuestUiWeb {
	
	private WebView mWebViewMap;
	private long index_exitTime;
	
	@Override
	public void onStart() {
		super.onStart();
		
		setContentView(R.layout.guest_main_layout);
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_3);
		ib.setImageResource(R.drawable.guest_top3_2);
				
		mWebViewMap = (WebView) findViewById(R.id.web_map);
		mWebViewMap.getSettings().setJavaScriptEnabled(true);
		mWebViewMap.setWebViewClient(new WebViewClient(){
	
		});
		mWebViewMap.loadUrl(GuestC.web.about1);
		
		this.setWebView(mWebViewMap);
		this.startWebView();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebViewMap.canGoBack()) {
			mWebViewMap.goBack();
			return true;
			}else if (keyCode == KeyEvent.KEYCODE_BACK) {
				Intent intent = new Intent(UiGuestContentAbout.this,UiGuestContentUsList.class);
				startActivity(intent);
				this.finish();
				//getOut();
				return true;
				} else {
					return super.onKeyDown(keyCode, event);
					}
		}
	
	protected void getOut() {
		long nowTime = System.currentTimeMillis();
		if (nowTime - index_exitTime > 3000) {
			Toast toast = Toast.makeText(this, "再按一次关闭关于我们窗口！", Toast.LENGTH_SHORT);
			toast.show();
			index_exitTime = nowTime;
		} else {
			Intent intent = new Intent(UiGuestContentAbout.this,UiGuestContentUsList.class);
			startActivity(intent);
			this.finish();
		}
	}
}