package com.zjgx.zixun.guest.ui;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.BaseGuestUiAuth;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class UiC extends BaseGuestUiAuth {

	private int[] idarr = new int[]{R.id.tv1,R.id.tv2,R.id.tv3,R.id.tv4,R.id.tv5,R.id.tv6,R.id.tv7,R.id.tv8};
	private int[] colorarr = new int[]{0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF};
	private int[] bgarr = new int[]{0xFFFF6666,0xFF1e67c0,0xFFd47756,0xFF5a626f,0xFFee7434,0xFF3eadeb,0xFF0385fd,0xFF00a179};
	private String[] textarr = new String[]{"特区公告","特区新闻","政策公开","发文公开","特区荣誉","媒体报道","政策解读","材料下载"};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_c);
		for(int i=0;i<idarr.length;i++){
			TextView tv = (TextView)findViewById(idarr[i]);
			tv.setText(textarr[i]);
			tv.setBackgroundColor(bgarr[i]);
			tv.setTextColor(colorarr[i]);
			tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					TextView t = (TextView)v;
					if(idarr[0] == R.id.tv1){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews1.class);
					}
					if(idarr[1] == R.id.tv2){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews2.class);
					}
					if(idarr[2] == R.id.tv3){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews3.class);
					}
					if(idarr[3] == R.id.tv4){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews4.class);
					}
					if(idarr[4] == R.id.tv5){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews5.class);
					}
					if(idarr[5] == R.id.tv6){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews6.class);
					}
					if(idarr[6] == R.id.tv7){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews7.class);
					}
					if(idarr[7] == R.id.tv8){
						showMessage("您点击的是 : "+t.getText().toString());
						forward(UiGuestNews8.class);
					}
					}
				});
			}
		}


	private void showMessage(String msg){
		Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
		}
	}