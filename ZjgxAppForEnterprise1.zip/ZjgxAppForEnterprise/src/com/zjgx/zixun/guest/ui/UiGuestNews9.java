package com.zjgx.zixun.guest.ui;

import android.content.Intent;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.BaseGuestUiWeb;
import com.zjgx.zixun.guest.base.GuestC;

//材料下载
public class UiGuestNews9 extends BaseGuestUiWeb {
	
	private WebView mWebViewMap;
	private long index_exitTime;
	
	@Override
	public void onStart() {
		super.onStart();
		
		setContentView(R.layout.guest_main_layout);
		mWebViewMap = (WebView) findViewById(R.id.web_map);
		mWebViewMap.getSettings().setJavaScriptEnabled(true);
		mWebViewMap.setWebViewClient(new WebViewClient(){

		});
		mWebViewMap.loadUrl(GuestC.web.news13);
		//mWebViewMap.setDownloadListener(new MyWebViewDownLoadListener());
		this.setWebView(mWebViewMap);
		this.startWebView();
	}
	
//	private class MyWebViewDownLoadListener implements DownloadListener {  
//		  
//        @Override  
//        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype,  
//                                    long contentLength) {  
//            Uri uri = Uri.parse(url);  
//            Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
//            startActivity(intent);  
//        }  
//  
//    }  
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebViewMap.canGoBack()) {
			mWebViewMap.goBack();
			return true;
			}else if (keyCode == KeyEvent.KEYCODE_BACK) {
				getOut();
				return true;
				} else {
					return super.onKeyDown(keyCode, event);
					}
		}
	
	protected void getOut() {
		long nowTime = System.currentTimeMillis();
		if (nowTime - index_exitTime > 3000) {
			Toast toast = Toast.makeText(this, "再按一次关闭材料阅读窗口！", Toast.LENGTH_SHORT);
			toast.show();
			index_exitTime = nowTime;
		} else {
			Intent intent = new Intent(UiGuestNews9.this,UiGuestZixunList.class);
			startActivity(intent);
			this.finish();
		}
	}
}