package com.zjgx.zixun.guest.ui;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.guest.base.BaseGuestUiAuth;
import com.zjgx.zixun.list.NewsList;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class UiGuestFashionAppList extends BaseGuestUiAuth {

	private NewsList newsListAdapter;
	
	private int[] idarr = new int[]{R.id.tv1,R.id.tv2,R.id.tv3,R.id.tv4,R.id.tv5,R.id.tv6,R.id.tv7,R.id.tv8};
	private int[] colorarr = new int[]{0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF,0xFFFFFFFF};
	private int[] bgarr = new int[]{0xFFFF6666,0xFF1e67c0,0xFFd47756,0xFF5a626f,0xFFee7434,0xFF3eadeb,0xFF0385fd,0xFF00a179};
	private String[] textarr = new String[]{"用户登录","用户注册","品牌标签","产品资讯","我的产品","帐号设置","后台管理","更多功能"};
//	private int[] draw = new int[]{R.drawable.listpic,R.drawable.listpic,R.drawable.listpic,
//			R.drawable.listpic,R.drawable.listpic,R.drawable.listpic,R.drawable.listpic,R.drawable.listpic};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_guest_zixun_list);
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_2);
		ib.setImageResource(R.drawable.guest_top2_2);
		if (textarr.length < 7){
		for(int i=0;i<textarr.length;i++){
			TextView tv = (TextView)findViewById(idarr[i]);
			tv.setText(textarr[i]);
			tv.setBackgroundColor(bgarr[i]);
			tv.setTextColor(colorarr[i]);
			
//			WindowManager windowManager = getWindowManager();
//	        Display display = windowManager.getDefaultDisplay();
//	        int screenWidth = display.getWidth();
//	        int screenHeight = display.getHeight();
//			
//			Resources res = getResources();
//			Drawable image = res.getDrawable(draw[i]);
//			image.setBounds(1, 2, screenWidth/3, screenHeight/3);
//			
//			tv.setCompoundDrawablesWithIntrinsicBounds(null, image, null, null);
			tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					TextView t = (TextView)v;
					switch (v.getId()) {
					case R.id.tv1:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestMySiteWeibo.class);
						break;
					case R.id.tv2:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestMySiteWeixin.class);
						break;
					case R.id.tv3:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestFashionBbs.class);
						break;
					case R.id.tv4:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestFashionMap.class);
						break;
					case R.id.tv5:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestFashionMail.class);
						break;
					case R.id.tv6:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestFashionMeet.class);
						break;
					case R.id.tv7:
						showMessage("正在为你加载 : "+t.getText().toString());
						forward(UiGuestManage7.class);
						break;
					}
					}
				});
			}
		}
		if (textarr.length-1 > 6){
			for(int i=0;i<textarr.length-1;i++){
				TextView tv = (TextView)findViewById(idarr[i]);
				tv.setText(textarr[i]);
				tv.setBackgroundColor(bgarr[i]);
				tv.setTextColor(colorarr[i]);
				
//				WindowManager windowManager = getWindowManager();
//		        Display display = windowManager.getDefaultDisplay();
//		        int screenWidth = display.getWidth();
//		        int screenHeight = display.getHeight();
//				
//				Resources res = getResources();
//				Drawable image = res.getDrawable(draw[i]);
//				image.setBounds(1, 2, screenWidth/3, screenHeight/3);
//				
//				tv.setCompoundDrawablesWithIntrinsicBounds(null, image, null, null);
				tv.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						TextView t = (TextView)v;
						switch (v.getId()) {
						case R.id.tv1:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestMySiteWeibo.class);
							break;
						case R.id.tv2:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestMySiteWeixin.class);
							break;
						case R.id.tv3:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestFashionBbs.class);
							break;
						case R.id.tv4:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestFashionMap.class);
							break;
						case R.id.tv5:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestFashionMail.class);
							break;
						case R.id.tv6:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestFashionMeet.class);
							break;
						case R.id.tv7:
							showMessage("正在为你加载 : "+t.getText().toString());
							forward(UiGuestManage7.class);
							break;
						}
						}
					});
				}
		TextView tv = (TextView)findViewById(idarr[textarr.length-1]);
		tv.setText(textarr[textarr.length-1]);
		tv.setBackgroundColor(bgarr[textarr.length-1]);
		tv.setTextColor(colorarr[textarr.length-1]);
		
//		WindowManager windowManager = getWindowManager();
//        Display display = windowManager.getDefaultDisplay();
//        int screenWidth = display.getWidth();
//        int screenHeight = display.getHeight();
//		
//        Resources res = getResources();
//		Drawable image = res.getDrawable(draw[textarr.length-1]);
//		image.setBounds(1, 2, screenWidth/3, screenHeight/3);
//		
//		tv.setCompoundDrawablesWithIntrinsicBounds(null, image, null, null);
		
		tv.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				TextView t = (TextView)v;
					showMessage("正在为你加载 : "+t.getText().toString());
					forward(UiGuestFashionAppListMore.class);
				}
			});}
		}
	
	private void showMessage(String msg){
		Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
		}
	
	@SuppressWarnings("unused")
	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					newsListAdapter.notifyDataSetChanged();
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiGuestZixunList.class);
		}
		return super.onKeyDown(keyCode, event);
	}
	}