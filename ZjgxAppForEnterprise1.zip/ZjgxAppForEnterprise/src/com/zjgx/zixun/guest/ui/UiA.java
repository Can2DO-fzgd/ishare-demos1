package com.zjgx.zixun.guest.ui;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.GuestC;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.DownloadListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class UiA extends Activity {
   
	WebView webView;
   
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_a);
        
        this.webView=(WebView) this.findViewById(R.id.webview);
        this.webView.getSettings().setSupportZoom(false);
        this.webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        //this.webView.loadUrl("http://www.can2do.com/platform/zjgx/downAtta.action?atta=0fc8bbb3-d8c0-43e3-894c-c5aefeab7e89.zip");
        this.webView.loadUrl(GuestC.web.news13);
        this.webView.setWebViewClient(new WebViewClientDemo());
        
        webView.setDownloadListener(new DownloadListener() {
            @Override
			public void onDownloadStart(String url, String userAgent,
                            String contentDisposition, String mimetype,
                            long contentLength) {
          //实现下载的代码
            Log.i("tag", "url="+url);             
            Log.i("tag", "userAgent="+userAgent);  
            Log.i("tag", "contentDisposition="+contentDisposition);           
            Log.i("tag", "mimetype="+mimetype);  
            Log.i("tag", "contentLength="+contentLength);
           Uri uri = Uri.parse(url);
           Intent intent = new Intent(Intent.ACTION_VIEW,uri);
           startActivity(intent);
            }
    });
    }
  private class WebViewClientDemo extends WebViewClient {
    @Override
    // 在WebView中而不是默认浏览器中显示页面
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
     view.loadUrl(url);
      return true;
     }
    }
  }