package com.zjgx.zixun.guest.base;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.base.BaseGuestUiMenu;
import com.zjgx.zixun.guest.ui.UiGuestContentUsList;
import com.zjgx.zixun.guest.ui.UiGuestFashionAppList;
import com.zjgx.zixun.guest.ui.UiGuestManage10;
import com.zjgx.zixun.guest.ui.UiGuestManage12;
import com.zjgx.zixun.guest.ui.UiGuestMySiteWeibo;
import com.zjgx.zixun.guest.ui.UiGuestZixunList;
import com.zjgx.zixun.model.Customer1;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

public class BaseGuestUiAuth extends BaseGuestUi {
	
	private RelativeLayout level2;
	
	private boolean isLevel2Show = true;
	
	protected static Customer1 customer = null;
	
	@Override
	public void onStart() {
		super.onStart();
		
		this.bindMainTop();
		this.bindMainTab();
		this.bindMainMenu();
	}
	
	private void bindMainTop () {
		ImageButton bTopZixun = (ImageButton) findViewById(R.id.main_top_1);
		ImageButton bTopFashion = (ImageButton) findViewById(R.id.main_top_2);
		ImageButton bTopContent = (ImageButton) findViewById(R.id.main_top_3);
		if (bTopZixun != null && bTopFashion != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.main_top_1:
							forward(UiGuestZixunList.class);
							break;
						case R.id.main_top_2:
							forward(UiGuestFashionAppList.class);
							break;
						case R.id.main_top_3:
							forward(UiGuestContentUsList.class);
							break;
					}
				}
			};
			bTopZixun.setOnClickListener(mOnClickListener);
			bTopFashion.setOnClickListener(mOnClickListener);
			bTopContent.setOnClickListener(mOnClickListener);
		}
	}
	
	private void bindMainMenu() {
		//隐藏2级导航菜单
		BaseGuestUiMenu.startAnimationOUT(level2, 500, 500);
		isLevel2Show = !isLevel2Show;
	}
	
	private void bindMainTab() {
		
		ImageButton home = (ImageButton) findViewById(R.id.home);
		ImageButton menu = (ImageButton) findViewById(R.id.menu);
		ImageButton mypage = (ImageButton) findViewById(R.id.mypage);
		ImageButton search = (ImageButton) findViewById(R.id.search);
		
		level2 = (RelativeLayout) findViewById(R.id.level2);
		if (mypage != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.search:
							forward(UiGuestMySiteWeibo.class);
							break;
						case R.id.mypage:
							forward(UiGuestManage10.class);
							break;
						case R.id.menu:
							forward(UiGuestManage12.class);
							toast("你已退出登录！");
							break;
					}
				}
			};
			
			menu.setOnClickListener(mOnClickListener);
			mypage.setOnClickListener(mOnClickListener);
			search.setOnClickListener(mOnClickListener);
		}
		
		home.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(!isLevel2Show){
					//显示2级导航菜单
					BaseGuestUiMenu.startAnimationIN(level2, 500);
				} else {
						//隐藏2级导航菜单
						BaseGuestUiMenu.startAnimationOUT(level2, 500, 0);
					}
				isLevel2Show = !isLevel2Show;
			}
		});
	}
}