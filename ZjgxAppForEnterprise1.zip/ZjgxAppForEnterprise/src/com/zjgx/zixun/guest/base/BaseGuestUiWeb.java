package com.zjgx.zixun.guest.base;

import com.zjgx.zixun.R;
import com.zjgx.zixun.guest.ui.UiGuestContentUsList;
import com.zjgx.zixun.guest.ui.UiGuestFashionAppList;
import com.zjgx.zixun.guest.ui.UiGuestManage10;
import com.zjgx.zixun.guest.ui.UiGuestManage12;
import com.zjgx.zixun.guest.ui.UiGuestMySiteWeibo;
import com.zjgx.zixun.guest.ui.UiGuestZixunList;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.webkit.JsResult;

abstract public class BaseGuestUiWeb extends BaseGuestUi {
	
	private RelativeLayout level2;
	
	private boolean isLevel2Show = true;
	
	private static final int MAX_PROGRESS = 100;
	private static final int DIALOG_PROGRESS = 1;
	
	private WebView webView;
	private int mProgress = 0;
	private ProgressDialog mProgressDialog;
	
	public WebView getWebView () {
		return this.webView;
	}
	
	public void setWebView (WebView webView) {
		this.webView = webView;
	}
	
	public void startWebView() {
		
		this.bindMainTop();
		this.bindMainTab();
		this.bindMainMenu();
		
		webView.setWebChromeClient(new WebChromeClient(){
			@Override
			public void onProgressChanged(WebView view, int progress){
				mProgress = progress;
				mProgressDialog.setProgress(mProgress);
				if (mProgress >= MAX_PROGRESS) {
					mProgressDialog.dismiss();
				}
			}
			
			@Override
            public boolean onJsAlert(WebView view, String url,  
                    String message, final JsResult result) {  
                new AlertDialog.Builder(BaseGuestUiWeb.this)
                    .setTitle("Notification")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, new AlertDialog.OnClickListener() {
                        @Override
						public void onClick(DialogInterface dialog, int which) {
                            result.confirm();
                        }
                    })
                    .setCancelable(false)
                    .create().show();
                return true;
            }
		});
	} 
	
	@Override
	public void onStart() {
		super.onStart();
		
		showDialog(DIALOG_PROGRESS);
		getWindow().requestFeature(Window.FEATURE_PROGRESS);
	} 
	
	@Override
	protected Dialog onCreateDialog(int id){
		switch (id) {
			case DIALOG_PROGRESS:
				mProgressDialog = new ProgressDialog(this);
				mProgressDialog.setTitle("正在努力加载中 ...");
				mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				mProgressDialog.setMax(MAX_PROGRESS);
				return mProgressDialog;
		}
		return null;
	}
	
	@Override
	protected void onPause() {
		webView.stopLoading();
		super.onPause();
	}
	
	private void bindMainTop () {
		ImageButton bTopZixun = (ImageButton) findViewById(R.id.main_top_1);
		ImageButton bTopFashion = (ImageButton) findViewById(R.id.main_top_2);
		ImageButton bTopContent = (ImageButton) findViewById(R.id.main_top_3);
		if (bTopZixun != null && bTopFashion != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
					case R.id.main_top_1:
						forward(UiGuestZixunList.class);
						break;
					case R.id.main_top_2:
						forward(UiGuestFashionAppList.class);
						break;
					case R.id.main_top_3:
						forward(UiGuestContentUsList.class);
						break;
					}
				}
			};
			bTopZixun.setOnClickListener(mOnClickListener);
			bTopFashion.setOnClickListener(mOnClickListener);
			bTopContent.setOnClickListener(mOnClickListener);
		}
	}
	
	private void bindMainMenu() {
		//隐藏2级导航菜单
		BaseGuestUiMenu.startAnimationOUT(level2, 500, 500);
		isLevel2Show = !isLevel2Show;
	}
	
	private void bindMainTab() {
		
		ImageButton home = (ImageButton) findViewById(R.id.home);
		ImageButton menu = (ImageButton) findViewById(R.id.menu);
		ImageButton mypage = (ImageButton) findViewById(R.id.mypage);
		ImageButton search = (ImageButton) findViewById(R.id.search);
		
		level2 = (RelativeLayout) findViewById(R.id.level2);
		if (mypage != null) {
			OnClickListener mOnClickListener = new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					switch (v.getId()) {
						case R.id.search:
							forward(UiGuestMySiteWeibo.class);
							break;
						case R.id.mypage:
							forward(UiGuestManage10.class);
							break;
						case R.id.menu:
							forward(UiGuestManage12.class);
							toast("你已退出登录！");
							break;
					}
				}
			};
			
			menu.setOnClickListener(mOnClickListener);
			mypage.setOnClickListener(mOnClickListener);
			search.setOnClickListener(mOnClickListener);
		}
		
		home.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(!isLevel2Show){
					//显示2级导航菜单
					BaseGuestUiMenu.startAnimationIN(level2, 500);
				} else {
						//隐藏2级导航菜单
						BaseGuestUiMenu.startAnimationOUT(level2, 500, 0);
					}
				isLevel2Show = !isLevel2Show;
			}
		});
	}
}