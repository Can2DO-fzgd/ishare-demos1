package com.zjgx.zixun.guest.base;

public final class GuestC {

	////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static final class web {
		//园区资讯应用
		public static final String base				= "http://www.njibi.com.cn";
		//特区公告
		public static final String news1			= base + "/more1_1.html";
		//特区新闻
		public static final String news2			= base + "/more1_2.html";
		//政策公开
		public static final String news3			= base + "/more1_12.html";
		//发文公开
		public static final String news4			= base + "/more1_13.html";
		//图片新闻
		public static final String news5			= base + "/more1_11.html";
		//特区荣誉
		public static final String news6			= base + "/more1_5.html";
		//媒体报道
		public static final String news7			= base + "/more1_8.html";
		//企业通道
		public static final String news8			= base + "/toLogin1.action";
		//企业走廊
		public static final String news9			= base + "/more1_17.html";
		//视频新闻
		public static final String news10			= base + "/more1_10.html";
		//公共服务走廊
		public static final String news11			= base + "/servicemobile.html";
		//政策解读
		public static final String news12			= base + "/more1_7.html";
		//材料阅读
		public static final String news13			= base + "/more1_6.html";
		//优惠政策
		public static final String news14			= base + "/more1_14.html";
		//人才政策
		public static final String news15			= base + "/more1_15.html";
		//部门联系
		public static final String phone			= base + "/contactusmobile.html";
		//产品走廊
		public static final String products			= base + "/more1_18.html";
		//在线留言
		public static final String messagemobile	= base + "/messagemobile.html";
		
		//////////////////////////////////////////////////////////////////////
		//时尚应用
		public static final String fashion			= "http://map.njibi.com.cn";
		//地图
		public static final String gomap			= fashion + "/gomap.php";
		//会议预订
		public static final String fashion2			= fashion + "/2014/meetmagan.html";
		//园区邮箱
		public static final String fashion3			= "http://ym.163.com";
		//园区论坛
		public static final String fashion4			=  base + "/bbs/forum.php?mobile=yes";
		
		///////////////////////////////////////////////////////////////////////////////////////
		//移动办公
		//关于我们
		public static final String content1			= fashion + "/2014/aboutus.html";
		//在线场地管理
		public static final String content2			= base + "/togardenmobile.html";
		//////////////////////////////////////////////////////////////////////
		//我的微站
		//微博平台
		public static final String mysite1			= fashion + "/2014/weibo.html";
		//微信平台
		public static final String mysite2			= fashion + "/2014/weixin.html";
		/////////////////////////////////////平台产品/////////////////////////////////////////////////
		public static final String product			= "http://www.can2do.com:811";
		public static final String types1			= product + "/recommend";
		public static final String types2			= product + "/new";
		public static final String types3			= product + "/hot";
		public static final String types4			= product + "/product/explore/types1";
		public static final String types5			= product + "/product/explore/types2";
		public static final String types6			= product + "/product/explore/types3";
		public static final String types7			= product + "/product/explore/types4";
		public static final String types8			= product + "/product/explore/more";
		public static final String types9			= product + "/product/explore/moretype1";
		public static final String types10			= product + "/search";
		////////////////////////////////////时尚应用///////////////////////////////////////////////////
		public static final String manage1			= product + "/login";
		public static final String manage2			= product + "/register";
		public static final String manage3			= product + "/tag";
		public static final String manage4			= product + "/article";
		public static final String manage5			= product + "/my/teaching/courses";
		public static final String manage6			= product + "/settings/";
		public static final String manage7			= product + "/admin/";
		public static final String manage8			= product + "/notification";
		public static final String manage9			= product + "/message/";
		public static final String manage10			= product + "/message/send/";
		public static final String manage11			= product + "/merchant";
		public static final String manage12			= product + "/logout";
		//////////////////////////////////关于我们/////////////////////////////////////////////////////
		public static final String about1			= product + "/page/aboutus";
		public static final String about2			= product + "/page/questions";
	}
}