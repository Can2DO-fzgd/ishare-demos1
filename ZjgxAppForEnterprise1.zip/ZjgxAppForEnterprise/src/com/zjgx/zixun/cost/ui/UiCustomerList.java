package com.zjgx.zixun.cost.ui;

import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseMessage;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.BaseUiAuth;
import com.zjgx.zixun.base.C;
import com.zjgx.zixun.list.CustomerList;
import com.zjgx.zixun.model.Customer;
import com.zjgx.zixun.ui.UiMoveOa;

//费用管理

public class UiCustomerList extends BaseUiAuth{
	private ListView customerListView;
	private CustomerList customerListAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customer_list);
		
		// set handler
		this.setHandler(new IndexHandler(this));
		
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);
	}
	
	@Override
	public void onStart(){
		super.onStart();
		
		// show all cost list
		this.doTaskAsync(C.task.enterpriseList, C.api.enterpriseList);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// async task callback methods
	
	@Override
	public void onTaskComplete(int taskId, BaseMessage message) {
		super.onTaskComplete(taskId, message);

		switch (taskId) {
			case C.task.enterpriseList:
				try {
					@SuppressWarnings("unchecked")
					final ArrayList<Customer> customerList = (ArrayList<Customer>) message.getResultList("Customer");
					// load face image
					for (Customer news : customerList) {
						loadImage(news.getFace());
					}
					// show text
					customerListView = (ListView) this.findViewById(R.id.app_index_list_view);
					customerListAdapter = new CustomerList(this, customerList);
					customerListView.setAdapter(customerListAdapter);
					customerListView.setOnItemClickListener(new OnItemClickListener(){
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
							Bundle params = new Bundle();
							params.putString("memId", customerList.get(pos).getId());
							params.putString("sign", customerList.get(pos).getSign());
							params.putString("mphone", customerList.get(pos).getMphone());
							overlay(UiCostTypeList.class, params);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
					toast(e.getMessage());
				}
				break;
		}
	}
	
	@Override
	public void onNetworkError (int taskId) {
		super.onNetworkError(taskId);
		toast(C.err.network);
		switch (taskId) {
			case C.task.enterpriseList:

				break;
		}
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// other methods
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiMoveOa.class);
		}
		return super.onKeyDown(keyCode, event);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	// inner classes
	
	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
					case BaseTask.LOAD_IMAGE:
						customerListAdapter.notifyDataSetChanged();
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
}