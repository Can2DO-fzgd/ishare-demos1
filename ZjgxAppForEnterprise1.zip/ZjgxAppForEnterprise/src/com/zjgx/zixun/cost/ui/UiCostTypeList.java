package com.zjgx.zixun.cost.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat; 

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;

import com.zjgx.zixun.R;
import com.zjgx.zixun.base.BaseHandler;
import com.zjgx.zixun.base.BaseTask;
import com.zjgx.zixun.base.BaseUi;
import com.zjgx.zixun.base.BaseUiAuth;
import com.zjgx.zixun.list.NewsList;

@SuppressLint("SimpleDateFormat")
public class UiCostTypeList extends BaseUiAuth {

	private NewsList newsListAdapter;
	private GridView gridview;

	private String memId = null;
	private String sign = null;
	private String mphone = null;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_cost_list);

		// set handler
		this.setHandler(new IndexHandler(this));

		// get params
		Bundle params = this.getIntent().getExtras();
		memId = params.getString("memId");
		sign = params.getString("sign");
		mphone = params.getString("mphone");
				
		// tab button
		ImageButton ib = (ImageButton) this.findViewById(R.id.main_top_1);
		ib.setImageResource(R.drawable.top_moveoa_2);

		// 准备要添加的数据条目
		List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
		
/////////////////////////////////////全部费用////////////////////////////////
//types1-全部房租
		Map<String, Object> item1 = new HashMap<String, Object>();
		item1.put("imageItem", R.drawable.cost_type1);
		item1.put("textItem", "全部房租缴费信息");
		items.add(item1);
//types2-全部水费
		Map<String, Object> item2 = new HashMap<String, Object>();
		item2.put("imageItem", R.drawable.cost_type2);
		item2.put("textItem", "全部水费缴费信息");
		items.add(item2);
//types3-全部电费
		Map<String, Object> item3 = new HashMap<String, Object>();
		item3.put("imageItem", R.drawable.cost_type3);
		item3.put("textItem", "全部电费缴费信息");
		items.add(item3);
//types4-全部物业费
		Map<String, Object> item4 = new HashMap<String, Object>();
		item4.put("imageItem", R.drawable.cost_type4);
		item4.put("textItem", "全部物业费缴费信息");
		items.add(item4);
		
////////////////////////////////////已缴费用/////////////////////////////////
//types1-已缴房租费用信息
		Map<String, Object> item5 = new HashMap<String, Object>();
		item5.put("imageItem", R.drawable.cost_type5);
		item5.put("textItem", "已缴房租费用信息");
		items.add(item5);
//types2-已缴水费费用信息
		Map<String, Object> item6 = new HashMap<String, Object>();
		item6.put("imageItem", R.drawable.cost_type6);
		item6.put("textItem", "已缴水费费用信息");
		items.add(item6);
//types3-已缴电费费用信息
		Map<String, Object> item7 = new HashMap<String, Object>();
		item7.put("imageItem", R.drawable.cost_type7);
		item7.put("textItem", "已缴电费费用信息");
		items.add(item7);
//types4-已缴物业费费用信息
		Map<String, Object> item8 = new HashMap<String, Object>();
		item8.put("imageItem", R.drawable.cost_type8);
		item8.put("textItem", "已缴物业费费用信息");
		items.add(item8);
		
///////////////////////////////////未缴费用//////////////////////////////////
//types1-未缴房租费用信息
		Map<String, Object> item9 = new HashMap<String, Object>();
		item9.put("imageItem", R.drawable.cost_type9);
		item9.put("textItem", "未缴房租费用信息");
		items.add(item9);
//types2-未缴水费费用信息
		Map<String, Object> item10 = new HashMap<String, Object>();
		item10.put("imageItem", R.drawable.cost_type10);
		item10.put("textItem", "未缴水费费用信息");
		items.add(item10);
//types3-未缴电费费用信息
		Map<String, Object> item11 = new HashMap<String, Object>();
		item11.put("imageItem", R.drawable.cost_type11);
		item11.put("textItem", "未缴电费费用信息");
		items.add(item11);
//types4-未缴物业费费用信息
		Map<String, Object> item12 = new HashMap<String, Object>();
		item12.put("imageItem", R.drawable.cost_type12);
		item12.put("textItem", "未缴物业费费用信息");
		items.add(item12);
		
/////////////////////////////////本月未缴费用////////////////////////////////////
//types1-本月未缴房租费用信息
		Map<String, Object> item13 = new HashMap<String, Object>();
		item13.put("imageItem", R.drawable.cost_type13);
		item13.put("textItem", "本月未缴房租费用信息");
		items.add(item13);
//types2-本月未缴水费费用信息
		Map<String, Object> item14 = new HashMap<String, Object>();
		item14.put("imageItem", R.drawable.cost_type14);
		item14.put("textItem", "本月未缴水费费用信息");
		items.add(item14);
//types3-本月未缴电费费用信息
		Map<String, Object> item15 = new HashMap<String, Object>();
		item15.put("imageItem", R.drawable.cost_type15);
		item15.put("textItem", "本月未缴电费费用信息");
		items.add(item15);
//types4-本月未缴物业费费用信息
		Map<String, Object> item16 = new HashMap<String, Object>();
		item16.put("imageItem", R.drawable.cost_type16);
		item16.put("textItem", "本月未缴物业费费用信息");
		items.add(item16);
		
/////////////////////////////////本月已缴费用////////////////////////////////////
//types1-本月已缴房租费用信息
		Map<String, Object> item17 = new HashMap<String, Object>();
		item17.put("imageItem", R.drawable.cost_type17);
		item17.put("textItem", "本月已缴房租费用信息");
		items.add(item17);
//types2-本月已缴水费费用信息
		Map<String, Object> item18 = new HashMap<String, Object>();
		item18.put("imageItem", R.drawable.cost_type18);
		item18.put("textItem", "本月已缴水费费用信息");
		items.add(item18);
//types3-本月已缴电费费用信息
		Map<String, Object> item19 = new HashMap<String, Object>();
		item19.put("imageItem", R.drawable.cost_type19);
		item19.put("textItem", "本月已缴电费费用信息");
		items.add(item19);
//types4-本月已缴物业费费用信息
		Map<String, Object> item20 = new HashMap<String, Object>();
		item20.put("imageItem", R.drawable.cost_type20);
		item20.put("textItem", "本月已缴物业费费用信息");
		items.add(item20);

		
		// 实例化一个适配器
		SimpleAdapter adapter = new SimpleAdapter(this, items,
				R.layout.grid_item, new String[] { "imageItem", "textItem" },
				new int[] { R.id.image_item, R.id.text_item });
		
		// 获得GridView实例
		gridview = (GridView) findViewById(R.id.mygridview);
		
		// 将GridView和数据适配器关联
		gridview.setAdapter(adapter);
		
		// 点击跳转事件
		gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				switch (arg2) {
				
/////////////////////////////////////全部费用////////////////////////////////
				case 0:
					Bundle params = new Bundle();
					params.putString("memId", memId);
					//params.putString("sign", sign);
					params.putString("feetype", "1");
					params.putString("jf", "1");
					params.putString("fdate", "2014-02");
					params.putString("tag1", "房租");
					overlay(UiCostList1.class, params);
					break;
				case 1:
					Bundle params1 = new Bundle();
					params1.putString("memId", memId);
					//params1.putString("sign", sign);
					params1.putString("feetype", "2");
					params1.putString("jf", "1");
					params1.putString("fdate", "2014-02");
					params1.putString("tag1", "水费");
					overlay(UiCostList1.class, params1);
					break;
				case 2:
					Bundle params2 = new Bundle();
					params2.putString("memId", memId);
					//params2.putString("sign", sign);
					params2.putString("feetype", "3");
					params2.putString("jf", "1");
					params2.putString("fdate", "2014-02");
					params2.putString("tag1", "电费");
					overlay(UiCostList1.class, params2);
					break;
				case 3:
					Bundle params3 = new Bundle();
					params3.putString("memId", memId);
					//params3.putString("sign", sign);
					params3.putString("feetype", "4");
					params3.putString("jf", "1");
					params3.putString("fdate", "2014-02");
					params3.putString("tag1", "物业费");
					overlay(UiCostList1.class, params3);
					break;
////////////////////////////////////已缴费用/////////////////////////////////
				case 4:
					Bundle params4 = new Bundle();
					params4.putString("memId", memId);
					params4.putString("sign", sign);
					params4.putString("feetype", "1");
					params4.putString("jf", "1");
					params4.putString("fdate", "2014-02");
					params4.putString("tag1", "房租");
					overlay(UiCostList2.class, params4);
					break;
				case 5:
					Bundle params5 = new Bundle();
					params5.putString("memId", memId);
					params5.putString("sign", sign);
					params5.putString("feetype", "2");
					params5.putString("jf", "1");
					params5.putString("fdate", "2014-02");
					params5.putString("tag1", "水费");
					overlay(UiCostList2.class, params5);
					break;
				case 6:
					Bundle params6 = new Bundle();
					params6.putString("memId", memId);
					params6.putString("sign", sign);
					params6.putString("feetype", "3");
					params6.putString("jf", "1");
					params6.putString("fdate", "2014-02");
					params6.putString("tag1", "电费");
					overlay(UiCostList2.class, params6);
					break;
				case 7:
					Bundle params7 = new Bundle();
					params7.putString("memId", memId);
					params7.putString("sign", sign);
					params7.putString("feetype", "4");
					params7.putString("jf", "1");
					params7.putString("fdate", "2014-02");
					params7.putString("tag1", "物业费");
					overlay(UiCostList2.class, params7);
					break;
////////////////////////////////////未缴费用/////////////////////////////////
				case 8:
					Bundle params8 = new Bundle();
					params8.putString("memId", memId);
					params8.putString("sign", sign);
					params8.putString("mphone", mphone);
					params8.putString("feetype", "1");
					params8.putString("jf", "0");
					params8.putString("fdate", "2014-02");
					params8.putString("tag1", "房租");
					overlay(UiCostList3.class, params8);
					break;
				case 9:
					Bundle params9 = new Bundle();
					params9.putString("memId", memId);
					params9.putString("sign", sign);
					params9.putString("mphone", mphone);
					params9.putString("feetype", "2");
					params9.putString("jf", "0");
					params9.putString("fdate", "2014-02");
					params9.putString("tag1", "水费");
					overlay(UiCostList3.class, params9);
					break;
				case 10:
					Bundle params10 = new Bundle();
					params10.putString("memId", memId);
					params10.putString("sign", sign);
					params10.putString("mphone", mphone);
					params10.putString("feetype", "3");
					params10.putString("jf", "0");
					params10.putString("fdate", "2014-02");
					params10.putString("tag1", "电费");
					overlay(UiCostList3.class, params10);
					break;
				case 11:
					Bundle params11 = new Bundle();
					params11.putString("memId", memId);
					params11.putString("sign", sign);
					params11.putString("mphone", mphone);
					params11.putString("feetype", "4");
					params11.putString("jf", "0");
					params11.putString("fdate", "2014-02");
					params11.putString("tag1", "物业费");
					overlay(UiCostList3.class, params11);
					break;
/////////////////////////////////本月未缴费用////////////////////////////////////
				case 12:
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM");
					String date=sdf.format(new java.util.Date());
					Bundle params12 = new Bundle();
					params12.putString("memId", memId);
					params12.putString("sign", sign);
					params12.putString("mphone", mphone);
					params12.putString("feetype", "1");
					params12.putString("jf", "0");
					params12.putString("fdate", date);
					params12.putString("tag1", "房租");
					overlay(UiCostList4.class, params12);
					break;
				case 13:
					SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM");
					String date1=sdf1.format(new java.util.Date());
					Bundle params13 = new Bundle();
					params13.putString("memId", memId);
					params13.putString("sign", sign);
					params13.putString("mphone", mphone);
					params13.putString("feetype", "2");
					params13.putString("jf", "0");
					params13.putString("fdate", date1);
					params13.putString("tag1", "水费");
					overlay(UiCostList4.class, params13);
					break;
				case 14:
					SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM");
					String date2=sdf2.format(new java.util.Date());
					Bundle params14 = new Bundle();
					params14.putString("memId", memId);
					params14.putString("sign", sign);
					params14.putString("mphone", mphone);
					params14.putString("feetype", "3");
					params14.putString("jf", "0");
					params14.putString("fdate", date2);
					params14.putString("tag1", "电费");
					overlay(UiCostList4.class, params14);
					break;
				case 15:
					SimpleDateFormat sdf3=new SimpleDateFormat("yyyy-MM");
					String date3=sdf3.format(new java.util.Date());
					Bundle params15 = new Bundle();
					params15.putString("memId", memId);
					params15.putString("sign", sign);
					params15.putString("mphone", mphone);
					params15.putString("feetype", "4");
					params15.putString("jf", "0");
					params15.putString("fdate", date3);
					params15.putString("tag1", "物业费");
					overlay(UiCostList4.class, params15);
					break;
/////////////////////////////////本月已缴费用////////////////////////////////////
				case 16:
					SimpleDateFormat sdf4=new SimpleDateFormat("yyyy-MM");
					String date4=sdf4.format(new java.util.Date());
					Bundle params16 = new Bundle();
					params16.putString("memId", memId);
					params16.putString("sign", sign);
					params16.putString("feetype", "1");
					params16.putString("jf", "1");
					params16.putString("fdate", date4);
					params16.putString("tag1", "房租");
					overlay(UiCostList5.class, params16);
					break;
				case 17:
					SimpleDateFormat sdf5=new SimpleDateFormat("yyyy-MM");
					String date5=sdf5.format(new java.util.Date());
					Bundle params17 = new Bundle();
					params17.putString("memId", memId);
					params17.putString("sign", sign);
					params17.putString("feetype", "2");
					params17.putString("jf", "1");
					params17.putString("fdate", date5);
					params17.putString("tag1", "水费");
					overlay(UiCostList5.class, params17);
					break;
				case 18:
					SimpleDateFormat sdf6=new SimpleDateFormat("yyyy-MM");
					String date6=sdf6.format(new java.util.Date());
					Bundle params18 = new Bundle();
					params18.putString("memId", memId);
					params18.putString("sign", sign);
					params18.putString("feetype", "3");
					params18.putString("jf", "1");
					params18.putString("fdate", date6);
					params18.putString("tag1", "电费");
					overlay(UiCostList5.class, params18);
					break;
				case 19:
					SimpleDateFormat sdf7=new SimpleDateFormat("yyyy-MM");
					String date7=sdf7.format(new java.util.Date());
					Bundle params19 = new Bundle();
					params19.putString("memId", memId);
					params19.putString("sign", sign);
					params19.putString("feetype", "4");
					params19.putString("jf", "1");
					params19.putString("fdate", date7);
					params19.putString("tag1", "物业费");
					overlay(UiCostList5.class, params19);
					break;
				}
			}
		});
	}

	@SuppressLint("HandlerLeak")
	private class IndexHandler extends BaseHandler {
		public IndexHandler(BaseUi ui) {
			super(ui);
		}

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			try {
				switch (msg.what) {
				case BaseTask.LOAD_IMAGE:
					newsListAdapter.notifyDataSetChanged();
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				ui.toast(e.getMessage());
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.forward(UiCustomerList.class);
		}
		return super.onKeyDown(keyCode, event);
	}
}