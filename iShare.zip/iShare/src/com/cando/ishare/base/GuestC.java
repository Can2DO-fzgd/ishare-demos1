package com.cando.ishare.base;

public final class GuestC {

	////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static final class web {
		/////////////////////////////////////���²�Ʒ/////////////////////////////////////////////////
		public static final String product			= "http://www.can2do.com:811";
		public static final String product1			= product + "/recommend";
		public static final String product2			= product + "/new";
		public static final String product3			= product + "/hot";
		public static final String product4			= product + "/product/explore/types1";
		public static final String product5			= product + "/product/explore/types2";
		public static final String product6			= product + "/product/explore/types3";
		public static final String product7			= product + "/product/explore/types4";
		public static final String product8			= product + "/product/explore/more";
		public static final String product9			= product + "/product/explore/moretype1";
		public static final String product10		= product + "/search";
		public static final String product11		= product + "/product/explore/moretype1";
		public static final String product12		= product + "/search";
		////////////////////////////////////ʱ��Ӧ��///////////////////////////////////////////////////
		public static final String app1				= product + "/product/explore/types1";
		public static final String app2				= product + "/search";
		public static final String app3				= product + "/hot";
		public static final String app4				= product + "/product/explore/types1";
		public static final String app5				= product + "/product/explore/types2";
		public static final String app6				= product + "/product/explore/types3";
		public static final String app7				= product + "/product/explore/types4";
		public static final String app8				= product + "/product/explore/more";
		public static final String app9				= product + "/product/explore/moretype1";
		public static final String app10			= product + "/search";
		public static final String app11			= product + "/product/explore/moretype1";
		public static final String app12			= product + "/search";
		////////////////////////////////////�ҵķ���///////////////////////////////////////////////////
		public static final String share1			= product + "/login";
		public static final String share2			= product + "/register";
		public static final String share3			= product + "/tag";
		public static final String share4			= product + "/article";
		public static final String share5			= product + "/my/teaching/courses";
		public static final String share6			= product + "/settings/";
		public static final String share7			= product + "/admin/";
		public static final String share8			= product + "/notification";
		public static final String share9			= product + "/message/";
		public static final String share10			= product + "/message/send/";
		public static final String share11			= product + "/merchant";
		public static final String share12			= product + "/logout";
		//////////////////////////////////��ϵ����/////////////////////////////////////////////////////
		public static final String content1			= product + "/page/aboutus";
		public static final String content2			= product + "/page/questions";
	}
}