package com.cando.ishare.webpage;

import com.cando.ishare.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;


public class FragmentWeb4 extends Activity{

	private LJWebView mLJWebView = null;
	private String url = "";
	private String urlStr;
	private String Text;
	private String text = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_fragmentweb4);
		
		Intent intent = this.getIntent();
		urlStr = intent.getStringExtra("url");
		Text = intent.getStringExtra("content");
		url=urlStr;
		text=Text;
		
		TextView tv = (TextView)findViewById(R.id.content);
		tv.setText(text);
		tv.setTextColor(0xFFFFFFFF);
		
		mLJWebView = (LJWebView) findViewById(R.id.web);
		mLJWebView.setProgressStyle(LJWebView.Circle);
		mLJWebView.setBarHeight(8);
		mLJWebView.setClickable(true);
		mLJWebView.setUseWideViewPort(true);
		//mLJWebView.setSupportZoom(true);
		//mLJWebView.setBuiltInZoomControls(true);
		mLJWebView.setJavaScriptEnabled(true);
		mLJWebView.setCacheMode(WebSettings.LOAD_NO_CACHE);		
		mLJWebView.setWebViewClient(new WebViewClient() {

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				System.out.println("����URL =" + url);
				view.loadUrl(url);
				return true;
			}
		});

		mLJWebView.loadUrl(url);

	}

}
