package com.cando.ishare.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.cando.ishare.R;
import com.cando.ishare.base.GuestC;
import com.cando.ishare.webpage.FragmentWeb;
import com.cando.ishare.webpage.FragmentWeb1;
import com.cando.ishare.webpage.FragmentWeb4;

public class Fragment4 extends Fragment implements View.OnClickListener{

	private LinearLayout content1;
	private LinearLayout content2;
//	private LinearLayout content3;
//	private LinearLayout content4;
//	private LinearLayout content5;
//	private LinearLayout content6;
//	private LinearLayout content7;
//	private LinearLayout content8;
//	private LinearLayout content9;
//	private LinearLayout content10;
//	private LinearLayout content11;
//	private LinearLayout content12;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v=View.inflate(this.getActivity(), R.layout.ui_fragment4, null);
		setView(v);
		return v;
	}

	private void setView(View v) {
		content1 = (LinearLayout)v.findViewById(R.id.content_btn1);
		content2 = (LinearLayout)v.findViewById(R.id.content_btn2);
//		content3 = (LinearLayout)v.findViewById(R.id.content_btn3);
//		content4 = (LinearLayout)v.findViewById(R.id.content_btn4);
//		content5 = (LinearLayout)v.findViewById(R.id.content_btn5);
//		content6 = (LinearLayout)v.findViewById(R.id.content_btn6);
//		content7 = (LinearLayout)v.findViewById(R.id.content_btn7);
//		content8 = (LinearLayout)v.findViewById(R.id.content_btn8);
//		content9 = (LinearLayout)v.findViewById(R.id.content_btn9);
//		content10 = (LinearLayout)v.findViewById(R.id.content_btn10);
//		content11 = (LinearLayout)v.findViewById(R.id.content_btn11);
//		content12 = (LinearLayout)v.findViewById(R.id.content_btn12);
	}

	public void doOnClick(View v) {
		Intent in=new Intent(getActivity(),FragmentWeb4.class);
		switch (v.getId()) {
		case R.id.content_btn1:
			in.putExtra("url", GuestC.web.content1);
			in.putExtra("content", GuestC.web.content1);
			break;
		case R.id.content_btn2:
			in.putExtra("url", GuestC.web.content2);
			in.putExtra("content", GuestC.web.content2);
			break;
//		case R.id.content_btn3:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn4:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn5:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn6:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn7:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn8:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn9:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn10:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn11:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
//		case R.id.content_btn12:
//			in.putExtra("url", GuestC.web.content2);
//			in.putExtra("content", GuestC.web.content2);
//			break;
		}
		startActivity(in);
	}

	@Override
	public void onClick(View v) {
		
	}
}