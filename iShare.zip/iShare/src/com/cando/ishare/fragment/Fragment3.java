package com.cando.ishare.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.cando.ishare.R;
import com.cando.ishare.base.GuestC;
import com.cando.ishare.webpage.FragmentWeb;
import com.cando.ishare.webpage.FragmentWeb1;
import com.cando.ishare.webpage.FragmentWeb3;

public class Fragment3 extends Fragment implements View.OnClickListener{

	private LinearLayout share1;
	private LinearLayout share2;
//	private LinearLayout share3;
//	private LinearLayout share4;
//	private LinearLayout share5;
//	private LinearLayout share6;
//	private LinearLayout share7;
//	private LinearLayout share8;
//	private LinearLayout share9;
//	private LinearLayout share10;
//	private LinearLayout share11;
//	private LinearLayout share12;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v=View.inflate(this.getActivity(), R.layout.ui_fragment3, null);
		setView(v);
		return v;
	}

	private void setView(View v) {
		share1 = (LinearLayout)v.findViewById(R.id.share_btn1);
		share2 = (LinearLayout)v.findViewById(R.id.share_btn2);
//		share3 = (LinearLayout)v.findViewById(R.id.share_btn3);
//		share4 = (LinearLayout)v.findViewById(R.id.share_btn4);
//		share5 = (LinearLayout)v.findViewById(R.id.share_btn5);
//		share6 = (LinearLayout)v.findViewById(R.id.share_btn6);
//		share7 = (LinearLayout)v.findViewById(R.id.share_btn7);
//		share8 = (LinearLayout)v.findViewById(R.id.share_btn8);
//		share9 = (LinearLayout)v.findViewById(R.id.share_btn9);
//		share10 = (LinearLayout)v.findViewById(R.id.share_btn10);
//		share11 = (LinearLayout)v.findViewById(R.id.share_btn11);
//		share12 = (LinearLayout)v.findViewById(R.id.share_btn12);
	}

	public void doOnClick(View v) {
		Intent in=new Intent(getActivity(),FragmentWeb3.class);
		switch (v.getId()) {
		case R.id.share_btn1:
			in.putExtra("url", GuestC.web.share1);
			in.putExtra("share", GuestC.web.share1);
			break;
		case R.id.share_btn2:
			in.putExtra("url", GuestC.web.share2);
			in.putExtra("share", GuestC.web.share2);
			break;
//		case R.id.share_btn3:
//			in.putExtra("url", GuestC.web.share3);
//			in.putExtra("share", GuestC.web.share3);
//			break;
//		case R.id.share_btn4:
//			in.putExtra("url", GuestC.web.share4);
//			in.putExtra("share", GuestC.web.share4);
//			break;
//		case R.id.share_btn5:
//			in.putExtra("url", GuestC.web.share5);
//			in.putExtra("share", GuestC.web.share5);
//			break;
//		case R.id.share_btn6:
//			in.putExtra("url", GuestC.web.share6);
//			in.putExtra("share", GuestC.web.share6);
//			break;
//		case R.id.share_btn7:
//			in.putExtra("url", GuestC.web.share7);
//			in.putExtra("share", GuestC.web.share7);
//			break;
//		case R.id.share_btn8:
//			in.putExtra("url", GuestC.web.share8);
//			in.putExtra("share", GuestC.web.share8);
//			break;
//		case R.id.share_btn9:
//			in.putExtra("url", GuestC.web.share9);
//			in.putExtra("share", GuestC.web.share9);
//			break;
//		case R.id.share_btn10:
//			in.putExtra("url", GuestC.web.share10);
//			in.putExtra("share", GuestC.web.share10);
//			break;
//		case R.id.share_btn11:
//			in.putExtra("url", GuestC.web.share11);
//			in.putExtra("share", GuestC.web.share11);
//			break;
//		case R.id.share_btn12:
//			in.putExtra("url", GuestC.web.share12);
//			in.putExtra("share", GuestC.web.share12);
//			break;
		}
		startActivity(in);
	}

	@Override
	public void onClick(View v) {
		
	}
}