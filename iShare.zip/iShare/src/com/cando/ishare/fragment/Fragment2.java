package com.cando.ishare.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.cando.ishare.R;
import com.cando.ishare.base.GuestC;
import com.cando.ishare.webpage.FragmentWeb;
import com.cando.ishare.webpage.FragmentWeb1;
import com.cando.ishare.webpage.FragmentWeb2;

public class Fragment2 extends Fragment implements View.OnClickListener{

	private LinearLayout app1;
	private LinearLayout app2;
//	private LinearLayout app3;
//	private LinearLayout app4;
//	private LinearLayout app5;
//	private LinearLayout app6;
//	private LinearLayout app7;
//	private LinearLayout app8;
//	private LinearLayout app9;
//	private LinearLayout app10;
//	private LinearLayout app11;
//	private LinearLayout app12;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v=View.inflate(this.getActivity(), R.layout.ui_fragment2, null);
		setView(v);
		return v;
	}

	private void setView(View v) {
		app1 = (LinearLayout)v.findViewById(R.id.app_btn1);
		app2 = (LinearLayout)v.findViewById(R.id.app_btn2);
//		app3 = (LinearLayout)v.findViewById(R.id.app_btn3);
//		app4 = (LinearLayout)v.findViewById(R.id.app_btn4);
//		app5 = (LinearLayout)v.findViewById(R.id.app_btn5);
//		app6 = (LinearLayout)v.findViewById(R.id.app_btn6);
//		app7 = (LinearLayout)v.findViewById(R.id.app_btn7);
//		app8 = (LinearLayout)v.findViewById(R.id.app_btn8);
//		app9 = (LinearLayout)v.findViewById(R.id.app_btn9);
//		app10 = (LinearLayout)v.findViewById(R.id.app_btn10);
//		app11 = (LinearLayout)v.findViewById(R.id.app_btn11);
//		app12 = (LinearLayout)v.findViewById(R.id.app_btn12);
	}

	public void doOnClick(View v) {
		Intent in=new Intent(getActivity(),FragmentWeb2.class);
		switch (v.getId()) {
		case R.id.app_btn1:
			in.putExtra("url", GuestC.web.app1);
			in.putExtra("app", GuestC.web.app1);
			break;
		case R.id.app_btn2:
			in.putExtra("url", GuestC.web.app2);
			in.putExtra("app", GuestC.web.app2);
			break;
//		case R.id.app_btn3:
//			in.putExtra("url", GuestC.web.app3);
//			in.putExtra("app", GuestC.web.app3);
//			break;
//		case R.id.app_btn4:
//			in.putExtra("url", GuestC.web.app4);
//			in.putExtra("app", GuestC.web.app4);
//			break;
//		case R.id.app_btn5:
//			in.putExtra("url", GuestC.web.app5);
//			in.putExtra("app", GuestC.web.app5);
//			break;
//		case R.id.app_btn6:
//			in.putExtra("url", GuestC.web.app6);
//			in.putExtra("app", GuestC.web.app6);
//			break;
//		case R.id.app_btn7:
//			in.putExtra("url", GuestC.web.app7);
//			in.putExtra("app", GuestC.web.app7);
//			break;
//		case R.id.app_btn8:
//			in.putExtra("url", GuestC.web.app8);
//			in.putExtra("app", GuestC.web.app8);
//			break;
//		case R.id.app_btn9:
//			in.putExtra("url", GuestC.web.app9);
//			in.putExtra("app", GuestC.web.app9);
//			break;
//		case R.id.app_btn10:
//			in.putExtra("url", GuestC.web.app10);
//			in.putExtra("app", GuestC.web.app10);
//			break;
//		case R.id.app_btn11:
//			in.putExtra("url", GuestC.web.app11);
//			in.putExtra("app", GuestC.web.app11);
//			break;
//		case R.id.app_btn12:
//			in.putExtra("url", GuestC.web.app12);
//			in.putExtra("app", GuestC.web.app12);
//			break;
		}
		startActivity(in);
	}

	@Override
	public void onClick(View v) {
		
	}
}