package com.cando.ishare.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.cando.ishare.R;
import com.cando.ishare.webpage.FragmentWeb;
import com.cando.ishare.webpage.FragmentWeb1;
import com.cando.ishare.base.GuestC;

public class Fragment1 extends Fragment implements View.OnClickListener{

	private LinearLayout product1;
	private LinearLayout product2;
//	private LinearLayout product3;
//	private LinearLayout product4;
//	private LinearLayout product5;
//	private LinearLayout product6;
//	private LinearLayout product7;
//	private LinearLayout product8;
//	private LinearLayout product9;
//	private LinearLayout product10;
//	private LinearLayout product11;
//	private LinearLayout product12;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v=View.inflate(this.getActivity(), R.layout.ui_fragment1, null);
		setView(v);
		return v;
	}

	private void setView(View v) {
		product1 = (LinearLayout)v.findViewById(R.id.product_btn1);
		product2 = (LinearLayout)v.findViewById(R.id.product_btn2);
//		product3 = (LinearLayout)v.findViewById(R.id.product_btn3);
//		product4 = (LinearLayout)v.findViewById(R.id.product_btn4);
//		product5 = (LinearLayout)v.findViewById(R.id.product_btn5);
//		product6 = (LinearLayout)v.findViewById(R.id.product_btn6);
//		product7 = (LinearLayout)v.findViewById(R.id.product_btn7);
//		product8 = (LinearLayout)v.findViewById(R.id.product_btn8);
//		product9 = (LinearLayout)v.findViewById(R.id.product_btn9);
//		product10 = (LinearLayout)v.findViewById(R.id.product_btn10);
//		product11 = (LinearLayout)v.findViewById(R.id.product_btn11);
//		product12 = (LinearLayout)v.findViewById(R.id.product_btn12);
	}

	public void doOnClick(View v) {
		Intent in=new Intent(getActivity(),FragmentWeb1.class);
		switch (v.getId()) {
			case R.id.product_btn1:
				in.putExtra("url", GuestC.web.product1);
				in.putExtra("product", GuestC.web.product1);
				break;
			case R.id.product_btn2:
				in.putExtra("url", GuestC.web.product2);
				in.putExtra("product", GuestC.web.product2);
				break;
//			case R.id.product_btn3:
//				in.putExtra("url", GuestC.web.product3);
//				in.putExtra("product", GuestC.web.product3);
//				break;
//			case R.id.product_btn4:
//				in.putExtra("url", GuestC.web.product4);
//				in.putExtra("product", GuestC.web.product4);
//				break;
//			case R.id.product_btn5:
//				in.putExtra("url", GuestC.web.product5);
//				in.putExtra("product", GuestC.web.product5);
//				break;
//			case R.id.product_btn6:
//				in.putExtra("url", GuestC.web.product6);
//				in.putExtra("product", GuestC.web.product6);
//				break;
//			case R.id.product_btn7:
//				in.putExtra("url", GuestC.web.product7);
//				in.putExtra("product", GuestC.web.product7);
//				break;
//			case R.id.product_btn8:
//				in.putExtra("url", GuestC.web.product8);
//				in.putExtra("product", GuestC.web.product8);
//				break;
//			case R.id.product_btn9:
//				in.putExtra("url", GuestC.web.product9);
//				in.putExtra("product", GuestC.web.product9);
//				break;
//			case R.id.product_btn10:
//				in.putExtra("url", GuestC.web.product10);
//				in.putExtra("product", GuestC.web.product10);
//				break;
//			case R.id.product_btn11:
//				in.putExtra("url", GuestC.web.product11);
//				in.putExtra("product", GuestC.web.product11);
//				break;
//			case R.id.product_btn12:
//				in.putExtra("url", GuestC.web.product12);
//				in.putExtra("product", GuestC.web.product12);
//				break;
		}
		startActivity(in);
	}

	@Override
	public void onClick(View v) {
		
	}
}