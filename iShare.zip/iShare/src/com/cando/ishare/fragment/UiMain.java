package com.cando.ishare.fragment;

import java.util.ArrayList;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.cando.ishare.R;

public class UiMain extends FragmentActivity implements
		View.OnClickListener {

	ViewPager viewpager;
	Button[] btnArray;
	UiMainAdapter adapter;
	private int currentPageIndex = 0;
	private ArrayList<Fragment> datas;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.ui_main);
		
		viewpager = (ViewPager)this.findViewById(R.id.viewPager);
		adapter = new UiMainAdapter(this.getSupportFragmentManager(), null);
		viewpager.setAdapter(adapter);
		
		setupView();
		addListener();
		setButtonColor();
		viewpager.setCurrentItem(0);
//		viewpager.setCurrentItem(1);
//		viewpager.setCurrentItem(2);
//		viewpager.setCurrentItem(3);
	}

	private void setButtonColor() {
		for (int i = 0; i < btnArray.length; i++) {
			if (i == currentPageIndex) {
				btnArray[i].setTextColor(0xFFFFFFFF);
			} else {
				btnArray[i].setTextColor(0xFF000000);
			}
			
		}
	}

	long oldTime=0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		long currentTime=System.currentTimeMillis();
		
		if (keyCode == KeyEvent.KEYCODE_BACK && currentTime-oldTime>3*1000 ) {
			Toast.makeText(this, "�ٰ�һ���˳�Ӧ��", Toast.LENGTH_SHORT).show();
			oldTime=System.currentTimeMillis();
			return true;
		}else if (keyCode == KeyEvent.KEYCODE_BACK && currentTime-oldTime<3*1000) {
			oldTime=0;
			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private void addListener() {
		viewpager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrollStateChanged(int index) {
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			@Override
			public void onPageSelected(int pageIndex) {
				currentPageIndex = pageIndex;
				setButtonColor();
			}
		});

		for (Button btn : btnArray) {
			btn.setOnClickListener(this);
		}
	}
	
	Fragment1 f1=null;
	Fragment2 f2=null;
	Fragment3 f3=null;
	Fragment4 f4=null;
	private void setupView() {
		datas = new ArrayList<Fragment>();
		datas.add(f1 = new Fragment1());
		datas.add(f2 = new Fragment2());
		datas.add(f3 = new Fragment3());
		datas.add(f4 = new Fragment4());
		
		adapter.setDatas(datas);
		adapter.notifyDataSetChanged();

		btnArray=new Button[]{
				(Button)findViewById(R.id.btn1),
				(Button)findViewById(R.id.btn2),
				(Button)findViewById(R.id.btn3),
				(Button)findViewById(R.id.btn4),
		};
	}

	public void doOnClick(View v) {
		f1.doOnClick(v);
//		f2.doOnClick(v);
//		f3.doOnClick(v);
//		f4.doOnClick(v);
	}
	
	@Override
	public void onClick(View v) {
		try {
			switch (v.getId()) {
				case R.id.btn1:
					currentPageIndex = 0;
					break;
				case R.id.btn2:
					currentPageIndex = 1;
					break;
				case R.id.btn3:
					currentPageIndex = 2;
					break;
				case R.id.btn4:
					currentPageIndex = 3;
					break;
			}
			viewpager.setCurrentItem(currentPageIndex);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}